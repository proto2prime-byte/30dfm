#!/usr/bin/env python3
"""
run_jlms_smoke.py — <60s referee smoke: small-X table + bridge appendix.

Writes: benchmark_outputs/jlms_submission/smoke_log.txt

DR(18)=9 TESLA — smoke completion.
"""
from __future__ import annotations

import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "benchmark_outputs" / "jlms_submission" / "smoke_log.txt"

CMDS = [
    [sys.executable, "scripts/reproduce_table.py", "--X", "1e6", "--mode", "cited"],
    [sys.executable, "scripts/certify_nt06_delta.py"],
    [sys.executable, "scripts/certify_bridge_appendix.py"],
]


def main() -> int:
    lines = [
        "JLMS PAPER-I smoke log",
        f"started_utc: {datetime.now(timezone.utc).isoformat()}",
        "clay_rh_claim: false",
        "purpose: Empirical / constant sanity — not an infinitude proof",
        "",
    ]
    ok = True
    # LOOP_REASON: SIDE_EFFECTS - sequential smoke commands
    for cmd in CMDS:
        lines.append("$ " + " ".join(cmd))
        try:
            r = subprocess.run(
                cmd,
                cwd=str(ROOT),
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=120,
            )
        except subprocess.TimeoutExpired:
            lines.append("TIMEOUT")
            ok = False
            continue
        lines.append(f"exit_code: {r.returncode}")
        if r.stdout:
            lines.append(r.stdout[-1500:])
        if r.stderr:
            lines.append("STDERR:\n" + r.stderr[-500:])
        lines.append("-" * 60)
        if r.returncode != 0:
            ok = False
    lines.append(f"finished_utc: {datetime.now(timezone.utc).isoformat()}")
    lines.append(f"all_ok: {ok}")
    lines.append("*verified by vibecheck*")
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text("\n".join(lines), encoding="utf-8")
    print("Wrote", OUT, "all_ok=", ok)
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
# PHI-THON STATUS: GREEN
