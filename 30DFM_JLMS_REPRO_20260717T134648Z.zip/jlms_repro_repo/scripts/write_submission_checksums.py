#!/usr/bin/env python3
"""
write_submission_checksums.py — SHA256 of main JSON artifacts for the supplement.

DR(18)=9 TESLA — archival checksum completion.
"""
from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CERT = ROOT / "benchmark_outputs" / "rh_continuation"
OUT_DIR = ROOT / "benchmark_outputs" / "jlms_submission"
JLMS = ROOT / "benchmark_outputs" / "jlms_submission"
FILES = [
    CERT / "reproduce_table_last.json",
    CERT / "nt04_explicit_last.json",
    CERT / "nt06_delta_last.json",
    CERT / "bridge_appendix_last.json",
    CERT / "sensitivity_table_last.json",
    CERT / "verify_classical_strip_last.json",
    CERT / "gate_projection_last.json",
    ROOT / "benchmark_outputs" / "pre_submission_battery_last.json",
    # Main PDFs (if present in pack)
    JLMS / "paper_i_fixed_strip_0776.pdf",
    JLMS / "JLMS_COVER_LETTER.pdf",
    JLMS / "CLAIMS_AND_CAVEATS.pdf",
    JLMS / "UNSOLVED_PROBLEMS_SUITE.pdf",
]


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        # LOOP_REASON: PERFORMANCE - stream hash
        while True:
            chunk = f.read(1 << 20)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def main() -> int:
    rows = []
    # LOOP_REASON: SIDE_EFFECTS - hash each artifact
    for p in FILES:
        if not p.is_file():
            rows.append({"path": str(p.relative_to(ROOT)).replace("\\", "/"), "missing": True})
            continue
        rows.append(
            {
                "path": str(p.relative_to(ROOT)).replace("\\", "/"),
                "bytes": p.stat().st_size,
                "sha256": sha256_file(p),
            }
        )
    payload = {
        "schema": "submission_checksums_v1",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "clay_rh_claim": False,
        "reproduce_cmds": [
            "python scripts/reproduce_table.py --X 1e12 --mode cited",
            "python scripts/rerun_certify_all.py",
            "python scripts/certify_bridge_appendix.py",
            "python scripts/sensitivity_table.py --X 1e12",
            "python scripts/write_submission_checksums.py",
        ],
        "files": rows,
    }
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    out_json = OUT_DIR / "SUBMISSION_CHECKSUMS.json"
    out_txt = OUT_DIR / "SUBMISSION_CHECKSUMS.txt"
    out_json.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    lines = [
        "JLMS PAPER-I submission SHA256 checksums",
        f"Generated: {payload['generated_at_utc']}",
        "clay_rh_claim: false",
        "",
    ]
    for r in rows:
        if r.get("missing"):
            lines.append(f"MISSING  {r['path']}")
        else:
            lines.append(f"{r['sha256']}  {r['path']}  ({r['bytes']} bytes)")
    lines.extend(["", "*verified by vibecheck*", ""])
    out_txt.write_text("\n".join(lines), encoding="utf-8")
    print("[ok]", out_json)
    print("[ok]", out_txt)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
# PHI-THON STATUS: GREEN
