#!/usr/bin/env python3
"""
certify_nt06_delta.py — Explicit δ(σ) for Huxley → κ7 transfer (Lemma NT-06).

DR(18)=9 TESLA — density transfer bookkeeping.
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "benchmark_outputs" / "rh_continuation" / "nt06_delta_last.json"

SIGMAS = (0.90, 0.80, 0.776, 0.725, 0.60, 0.55, 0.52, 0.501)


def alpha_huxley(sigma: float) -> float:
    """Huxley 1972 exponent: N(σ,T) ≪ T^{3(1-σ)/(2-σ)} (log T)^K."""
    s = float(sigma)
    return 3.0 * (1.0 - s) / (2.0 - s)


def alpha_density_hyp(sigma: float) -> float:
    return 2.0 * (1.0 - float(sigma))


def delta_from_alpha(sigma: float, alpha_h: float) -> float:
    """δ = 2σ - (σ + α_H/2) = σ - α_H/2."""
    return float(sigma) - 0.5 * float(alpha_h)


def row(sigma: float) -> Dict[str, Any]:
    a_h = alpha_huxley(sigma)
    a_dh = alpha_density_hyp(sigma)
    d_h = delta_from_alpha(sigma, a_h)
    d_dh = delta_from_alpha(sigma, a_dh)
    cross = sigma + 0.5 * a_h
    return {
        "sigma": sigma,
        "alpha_H_huxley": a_h,
        "delta_huxley": d_h,
        "cross_exponent_huxley": cross,
        "diagonal_2sigma": 2.0 * sigma,
        "delta_positive_huxley": d_h > 0,
        "alpha_H_density_hyp": a_dh,
        "delta_density_hyp": d_dh,
        "required_for_sigma_0725_example": sigma == 0.725,
    }


def certify() -> Dict[str, Any]:
    rows: List[Dict[str, Any]] = [row(s) for s in SIGMAS]
    # LOOP_REASON: SIDE_EFFECTS - collect positivity
    all_pos = all(r["delta_positive_huxley"] for r in rows)
    ex = next(r for r in rows if abs(r["sigma"] - 0.725) < 1e-12)
    return {
        "schema": "nt06_delta_v1",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "lemma": "NT06_REFEREE_LEMMA.md",
        "citations": [
            "Huxley, Invent. Math. 15 (1972), Theorem 1",
            "Bourgain, IMRN 2000 (density hyp. for sigma >= 25/32)",
        ],
        "formula": {
            "alpha_H_huxley": "3(1-sigma)/(2-sigma)",
            "delta": "sigma - alpha_H/2",
            "cross_exponent": "sigma + alpha_H/2",
        },
        "rows": rows,
        "example_sigma_0725": {
            "sigma": 0.725,
            "delta_huxley": ex["delta_huxley"],
            "cross_exponent": ex["cross_exponent_huxley"],
            "diagonal": ex["diagonal_2sigma"],
            "pass": ex["delta_huxley"] > 0,
        },
        "all_delta_positive_on_ladder": all_pos,
        "clay_rh_claim": False,
        "status": "EXPLICIT_DELTA" if all_pos else "FAIL",
        "all_pass": all_pos,
        "reproduce_cmd": "python scripts/certify_nt06_delta.py",
        "note": (
            "Transfer is conditional on the cited density bound applying to the "
            "kappa_7 / P_GATE bilinear form (bounded projection)."
        ),
    }


def main() -> int:
    ap = argparse.ArgumentParser(description="Explicit NT-06 delta certificate")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()

    payload = certify()
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    if args.json:
        print(json.dumps(payload, indent=2))
    else:
        print("certify_nt06_delta  status=%s  all_pass=%s" % (payload["status"], payload["all_pass"]))
        print(
            "  example sigma=0.725  delta_huxley=%.6f  cross=%.6f  diag=%.6f"
            % (
                payload["example_sigma_0725"]["delta_huxley"],
                payload["example_sigma_0725"]["cross_exponent"],
                payload["example_sigma_0725"]["diagonal"],
            )
        )
        print(" ->", OUT)
    return 0 if payload["all_pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
# PHI-THON STATUS: GREEN
