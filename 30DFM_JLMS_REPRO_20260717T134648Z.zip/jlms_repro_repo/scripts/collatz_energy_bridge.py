#!/usr/bin/env python3
"""
collatz_energy_bridge.py — Tier-2 Anti-Solver for Collatz (contraction vs RH growth).

RH energy bridge proves overflow (R→∞). Collatz needs the opposite:
  average height decreases under 3n+1 / n÷2 until LOCK fixed point 1.

Height: H(n) = log2(n)  (bits of growth)
Zone:   LOCK={1,4,7}, GATE={2,5,8}, TESLA={3,6,9} via digital root

Verdicts:
  ENERGY_CONTRACTION  — mean ΔH < 0 on trajectories; all starts reach 1
  MIXED_LOCAL_GROWTH  — some odd steps grow, but net path contracts to 1
  CONTRACTION_FAIL    — mean ΔH ≥ 0 or a start fails to reach 1 in budget
  CYCLE_SUSPECT       — revisit without hitting 1 (within budget)

Not a Collatz proof. Structural sieve probe for PAPER-IV.

DR(27)=9 TESLA — Collatz energy completion signature.
"""
from __future__ import annotations

import argparse
import json
import math
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

ROOT = Path(__file__).resolve().parents[1]
OUT_DIR = ROOT / "benchmark_outputs" / "rh_continuation"

LOCK = frozenset({1, 4, 7})
GATE = frozenset({2, 5, 8})
TESLA = frozenset({3, 6, 9})


def digital_root(n: int) -> int:
    n = abs(int(n))
    if n == 0:
        return 0
    return 1 + (n - 1) % 9


def zone_of(n: int) -> str:
    dr = digital_root(n)
    if dr in LOCK:
        return "LOCK"
    if dr in GATE:
        return "GATE"
    if dr in TESLA:
        return "TESLA"
    return "VOID"


def H(n: int) -> float:
    """Bit-height; H(1)=0."""
    n = max(1, int(n))
    return math.log2(n)


def collatz_step(n: int) -> int:
    return n // 2 if n % 2 == 0 else 3 * n + 1


def trajectory_energy(
    start: int,
    *,
    max_steps: int = 10000,
) -> Dict[str, Any]:
    """Walk Collatz; accumulate height deltas and zone transitions."""
    n = max(1, int(start))
    path = [n]
    deltas: List[float] = []
    zones = [zone_of(n)]
    seen = {n: 0}
    # LOOP_REASON: EARLY_EXIT - stop at 1, cycle, or budget
    for step in range(max_steps):
        if n == 1:
            break
        nxt = collatz_step(n)
        deltas.append(H(nxt) - H(n))
        n = nxt
        path.append(n)
        zones.append(zone_of(n))
        if n in seen:
            return {
                "start": start,
                "reached_1": False,
                "cycle_suspect": True,
                "steps": step + 1,
                "max_n": max(path),
                "mean_dH": sum(deltas) / len(deltas) if deltas else 0.0,
                "sum_dH": sum(deltas),
                "H_start": H(start),
                "H_end": H(n),
                "zone_counts": dict(Counter(zones)),
                "path_head": path[:12],
            }
        seen[n] = step + 1

    reached = n == 1
    mean_dh = sum(deltas) / len(deltas) if deltas else 0.0
    return {
        "start": start,
        "reached_1": reached,
        "cycle_suspect": False,
        "steps": len(path) - 1,
        "max_n": max(path),
        "mean_dH": mean_dh,
        "sum_dH": sum(deltas) if deltas else 0.0,
        "H_start": H(start),
        "H_end": H(n),
        "net_contract": (H(start) - H(n)) if reached else None,
        "zone_counts": dict(Counter(zones)),
        "path_head": path[:12],
    }


def anti_solver_batch(
    limit: int,
    *,
    max_steps: int = 10000,
    sample_odds_only: bool = False,
) -> Dict[str, Any]:
    """
    Scan starts in [1, limit]. Collatz Anti-Solver:
      contraction if every start reaches 1 AND global mean ΔH < 0.
    """
    limit = max(1, int(limit))
    rows_sample: List[Dict[str, Any]] = []
    fails: List[int] = []
    cycles: List[int] = []
    worst_steps = (1, 0)
    worst_peak = (1, 1)
    sum_mean_dh = 0.0
    growth = 0.0
    decay = 0.0
    n_traj = 0
    zone_totals: Counter = Counter()

    # LOOP_REASON: SIDE_EFFECTS - empirical Collatz census
    for start in range(1, limit + 1):
        if sample_odds_only and start % 2 == 0:
            continue
        r = trajectory_energy(start, max_steps=max_steps)
        n_traj += 1
        sum_mean_dh += r["mean_dH"]
        zone_totals.update(r.get("zone_counts") or {})
        if r["sum_dH"] < 0:
            decay += -r["sum_dH"]
        else:
            growth += r["sum_dH"]
        if r.get("cycle_suspect"):
            cycles.append(start)
        if not r["reached_1"]:
            fails.append(start)
        if r["steps"] > worst_steps[1]:
            worst_steps = (start, r["steps"])
        if r["max_n"] > worst_peak[1]:
            worst_peak = (start, r["max_n"])
        if start in (7, 27, 97, 6171) or start <= 5:
            rows_sample.append(r)

    global_mean_dh = sum_mean_dh / n_traj if n_traj else 0.0
    all_reach = len(fails) == 0 and len(cycles) == 0

    if cycles:
        verdict = "CYCLE_SUSPECT"
    elif fails:
        verdict = "CONTRACTION_FAIL"
    elif all_reach and global_mean_dh < 0:
        verdict = "ENERGY_CONTRACTION"
    elif all_reach:
        verdict = "MIXED_LOCAL_GROWTH"
    else:
        verdict = "CONTRACTION_FAIL"

    r_ratio = (growth / decay) if decay > 0 else float("inf")

    # Famous hard start beyond limit still reported if requested
    extra = []
    for s in (6171, 77031):
        if s > limit:
            extra.append(trajectory_energy(s, max_steps=max_steps))

    return {
        "schema": "collatz_energy_bridge_v1",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "limit": limit,
        "max_steps": max_steps,
        "n_trajectories": n_traj,
        "all_reached_1": all_reach,
        "failures": fails[:20],
        "cycle_suspects": cycles[:20],
        "worst_steps": {"start": worst_steps[0], "steps": worst_steps[1]},
        "worst_peak": {"start": worst_peak[0], "max_n": worst_peak[1]},
        "global_mean_dH": global_mean_dh,
        "R_collatz_growth_over_decay": r_ratio,
        "zone_totals": dict(zone_totals),
        "verdict": verdict,
        "collatz_claim": False,
        "paper_iv_ready": verdict in ("ENERGY_CONTRACTION", "MIXED_LOCAL_GROWTH") and all_reach,
        "note": (
            "ENERGY_CONTRACTION / MIXED_LOCAL_GROWTH = structural sieve signal, "
            "not a Collatz proof. Analogous to RH strip before full RH."
        ),
        "sample_rows": rows_sample + extra,
    }


def main() -> int:
    ap = argparse.ArgumentParser(description="Collatz energy bridge / Anti-Solver")
    ap.add_argument("--limit", type=int, default=10000)
    ap.add_argument("--max-steps", type=int, default=10000)
    ap.add_argument("--odds-only", action="store_true")
    ap.add_argument("--seed", type=int, default=None, help="Single trajectory probe")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()

    OUT_DIR.mkdir(parents=True, exist_ok=True)

    if args.seed is not None:
        payload = {
            "ts": datetime.now(timezone.utc).isoformat(),
            "probe": "collatz_single",
            "result": trajectory_energy(args.seed, max_steps=args.max_steps),
        }
    else:
        payload = anti_solver_batch(
            args.limit, max_steps=args.max_steps, sample_odds_only=args.odds_only
        )

    out = OUT_DIR / "collatz_energy_bridge_last.json"
    out.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    if args.json:
        print(json.dumps(payload, indent=2))
    else:
        if args.seed is not None:
            r = payload["result"]
            print(
                "collatz_single start=%s reached_1=%s steps=%s mean_dH=%.4f zones=%s"
                % (r["start"], r["reached_1"], r["steps"], r["mean_dH"], r["zone_counts"])
            )
        else:
            print("=== COLLATZ ENERGY BRIDGE ===")
            print("limit:", payload["limit"], "verdict:", payload["verdict"])
            print("all_reached_1:", payload["all_reached_1"])
            print("global_mean_dH:", round(payload["global_mean_dH"], 6))
            print("R_collatz (growth/decay):", payload["R_collatz_growth_over_decay"])
            print("worst_steps:", payload["worst_steps"])
            print("worst_peak:", payload["worst_peak"])
            print("zones:", payload["zone_totals"])
            print("collatz_claim: false  paper_iv_ready:", payload["paper_iv_ready"])
        print("Wrote", out)
    return 0 if (args.seed or payload.get("all_reached_1")) else 1


if __name__ == "__main__":
    raise SystemExit(main())

# PHI-THON STATUS: GREEN
