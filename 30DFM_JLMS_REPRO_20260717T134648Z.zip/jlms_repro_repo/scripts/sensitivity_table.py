#!/usr/bin/env python3
"""
sensitivity_table.py — 1-page numeric sensitivity for R(σ,X) and δ_Hux(σ).

DR(27)=9 TESLA — sensitivity completion.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

OUT = ROOT / "benchmark_outputs" / "rh_continuation" / "sensitivity_table_last.json"
SIGMAS = (0.501, 0.51, 0.60, 0.725, 0.776)


def delta_hux(sigma: float) -> float:
    return float(sigma) - 3.0 * (1.0 - float(sigma)) / (2.0 * (2.0 - float(sigma)))


def R(sigma: float, X: float, *, c_E: float, c0: float, C_E: float) -> float:
    return (c_E * (c0**2) * (X ** (2.0 * sigma))) / (C_E * X)


def build(*, X: float) -> Dict[str, Any]:
    base = {"c_E": 0.5, "c0": 0.0415, "C_E": 1.0, "C_eps": 0.074}
    perturbs = [
        ("base", base),
        ("c0+5%", {**base, "c0": base["c0"] * 1.05}),
        ("c0-5%", {**base, "c0": base["c0"] * 0.95}),
        ("c_E=0.6", {**base, "c_E": 0.6}),
        ("C_E=0.9", {**base, "C_E": 0.9}),
        ("C_eps=0.069548", {**base, "C_eps": 0.069548}),
    ]
    rows: List[Dict[str, Any]] = []
    # LOOP_REASON: SIDE_EFFECTS - finite sigma x perturbation grid
    for name, consts in perturbs:
        for sigma in SIGMAS:
            rows.append(
                {
                    "perturbation": name,
                    "sigma": sigma,
                    "delta_huxley": delta_hux(sigma),
                    "R": R(sigma, X, c_E=consts["c_E"], c0=consts["c0"], C_E=consts["C_E"]),
                    "c_E": consts["c_E"],
                    "c0": consts["c0"],
                    "C_E": consts["C_E"],
                    "C_eps": consts["C_eps"],
                }
            )
    payload = {
        "schema": "sensitivity_table_v1",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "X": X,
        "base_constants": base,
        "master_formula": "R(sigma,X)=(c_E c0^2 X^{2 sigma})/(C_E X)",
        "delta_formula": "delta=sigma - 3(1-sigma)/(2(2-sigma))",
        "Y0_note": "NT-04 uses Y0=2e4; residual-power seal alone needs Y0~1e5 for B~6.42",
        "rows": rows,
        "clay_rh_claim": False,
        "reproduce_cmd": f"python scripts/sensitivity_table.py --X {X:g}",
    }
    return payload


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--X", type=float, default=1e12)
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()
    payload = build(X=float(args.X))
    OUT.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(payload, indent=2)
    OUT.write_text(text, encoding="utf-8")
    sha = hashlib.sha256(text.encode("utf-8")).hexdigest()
    payload["sha256_self"] = sha
    OUT.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    if args.json:
        print(json.dumps(payload, indent=2))
    else:
        print("sensitivity_table  X=%.3g  rows=%d  sha256=%s..." % (args.X, len(payload["rows"]), sha[:16]))
        print(" ->", OUT)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
# PHI-THON STATUS: GREEN
