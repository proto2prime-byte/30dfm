#!/usr/bin/env python3
"""
twin_slide — GATE-zone sieve for twin primes.

Structural theorem: twin starts for p>5 lie in {11,17,29} mod 30 with
DR(p) in {2,5,8} (GATE).

For each such p <= limit:
  - direct: p+2 prime (true twin)
  - else: Electric Slide on p+2 — if a GATE/WIDE offset hits a prime,
    record as "almost twin" (composite p+2 near a prime); misses tagged.

Not a proof of infinitude.

DR(27)=9 TESLA — twin slide completion.
"""
from __future__ import annotations

import argparse
import json
import math
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Set, Tuple

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from electric_slide_prime_finder import (  # noqa: E402
    GATE_OFFSETS,
    WIDE_OFFSETS,
    classify_miss,
    digital_root,
)

OUT_DIR = ROOT / "benchmark_outputs" / "rh_continuation"
TWIN_START_R30 = (11, 17, 29)
GATE_DR = (2, 5, 8)


def sieve_primes(limit: int) -> List[int]:
    limit = int(limit)
    if limit < 2:
        return []
    n = limit + 1
    is_p = bytearray(b"\x01") * n
    is_p[0:2] = b"\x00\x00"
    # LOOP_REASON: PERFORMANCE - classical sieve
    for i in range(2, int(math.isqrt(limit)) + 1):
        if is_p[i]:
            start = i * i
            is_p[start:n:i] = b"\x00" * (((n - 1 - start) // i) + 1)
    return [i for i in range(2, n) if is_p[i]]


def offset_hits_prime(q: int, prime_set: Set[int], offsets: Tuple[int, ...]) -> List[Tuple[int, int]]:
    hits = []
    for d in offsets:
        cand = q + d
        if cand > 1 and cand in prime_set:
            hits.append((d, cand))
    return hits


def twin_slide_census(limit: int, *, wide: bool = True) -> Dict[str, Any]:
    pad = 20
    primes = sieve_primes(limit + pad)
    prime_set: Set[int] = set(primes)
    offsets = WIDE_OFFSETS if wide else GATE_OFFSETS
    gate_starts = [
        p
        for p in primes
        if 5 < p <= limit and (p % 30) in TWIN_START_R30 and digital_root(p) in GATE_DR
    ]

    direct = 0
    slide_hits = 0
    misses = 0
    max_abs_delta = 0
    miss_sample: List[Dict[str, Any]] = []
    miss_tags: Dict[str, int] = {}
    family_counts = {11: 0, 17: 0, 29: 0}
    twin_family = {11: 0, 17: 0, 29: 0}

    # LOOP_REASON: STATE - twin start census
    for p in gate_starts:
        r = p % 30
        family_counts[r] = family_counts.get(r, 0) + 1
        q = p + 2
        if q in prime_set:
            direct += 1
            twin_family[r] = twin_family.get(r, 0) + 1
            continue
        hits = offset_hits_prime(q, prime_set, offsets)
        if hits:
            slide_hits += 1
            ad = abs(int(hits[0][0]))
            if ad > max_abs_delta:
                max_abs_delta = ad
        else:
            misses += 1
            tag = classify_miss(q)
            miss_tags[tag] = miss_tags.get(tag, 0) + 1
            if len(miss_sample) < 25:
                miss_sample.append({"p": p, "p2": q, "tag": tag, "r30": r})

    total = len(gate_starts)
    resolved = direct + slide_hits
    return {
        "ts": datetime.now(timezone.utc).isoformat(),
        "probe": "twin_slide",
        "limit": limit,
        "wide": wide,
        "twin_start_families": list(TWIN_START_R30),
        "gate_starts_tested": total,
        "direct_twins": direct,
        "slide_almost_p2": slide_hits,
        "misses": misses,
        "hit_rate_percent": 100.0 * resolved / max(1, total),
        "direct_twin_rate_percent": 100.0 * direct / max(1, total),
        "max_abs_delta": max_abs_delta,
        "family_start_counts": family_counts,
        "family_twin_counts": twin_family,
        "miss_tags": miss_tags,
        "miss_sample": miss_sample,
        "structural_note": "Twin starts in {11,17,29} mod 30 with GATE DR",
        "claim": "structural_plus_empirical_slide_not_infinitude",
        "rh_claim": False,
    }


def main() -> int:
    ap = argparse.ArgumentParser(description="Twin prime GATE-zone Electric Slide census")
    ap.add_argument("--limit", type=int, default=100000)
    ap.add_argument("--narrow", action="store_true")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()

    result = twin_slide_census(args.limit, wide=not args.narrow)
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    out = OUT_DIR / "twin_slide_last.json"
    out.write_text(json.dumps(result, indent=2), encoding="utf-8")

    if args.json:
        print(json.dumps(result, indent=2))
    else:
        print(
            "TWIN_SLIDE  limit=%d  cover=%.3f%%  direct_twins=%d  slide_almost=%d  misses=%d  max|delta|=%s"
            % (
                result["limit"],
                result["hit_rate_percent"],
                result["direct_twins"],
                result["slide_almost_p2"],
                result["misses"],
                result["max_abs_delta"],
            )
        )
        print("  direct twin rate: %.3f%%" % result["direct_twin_rate_percent"])
        print("  families starts:", result["family_start_counts"])
        print("  families twins:", result["family_twin_counts"])
        print("  miss_tags:", result["miss_tags"])
        print("  Wrote %s" % out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

# PHI-THON STATUS: GREEN
