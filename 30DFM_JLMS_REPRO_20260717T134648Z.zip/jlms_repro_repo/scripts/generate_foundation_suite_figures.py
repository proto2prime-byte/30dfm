#!/usr/bin/env python3
"""
generate_foundation_suite_figures.py — AMS-accessible plots for the foundation suite.

Born-accessible rules (DOI 10.1137/25M0010799):
  - color never sole channel (markers / hatch / linestyles)
  - high-contrast AMS sample palette on white
  - vector PDF (+ PNG preview)
  - alt text catalog written beside figures

Outputs:
  flux_text/papers/figures/*.pdf
  flux_text/papers/figures/*.png
  flux_text/papers/figures/FIGURE_MANIFEST.json
  updates AMS_ALT_TEXT_CATALOG.md rows via console report
"""
from __future__ import annotations

import json
import math
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List

ROOT = Path(__file__).resolve().parents[1]
CERT = ROOT / "benchmark_outputs" / "rh_continuation"
OUT = ROOT / "flux_text" / "papers" / "figures"
CATALOG = ROOT / "flux_text" / "papers" / "AMS_ALT_TEXT_CATALOG.md"

# AMS guideline sample colors (white bg, ≥3:1 non-text)
C_RED = "#CC2929"
C_TEAL = "#00A875"
C_BLUE = "#007A99"
C_ORANGE = "#DB7D0A"
C_BLACK = "#111111"


def _load(name: str) -> Dict[str, Any]:
    p = CERT / name
    return json.loads(p.read_text(encoding="utf-8"))


def _setup_mpl():
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    plt.rcParams.update(
        {
            "font.size": 11,
            "axes.titlesize": 12,
            "axes.labelsize": 11,
            "figure.facecolor": "white",
            "axes.facecolor": "white",
            "axes.edgecolor": C_BLACK,
            "axes.labelcolor": C_BLACK,
            "xtick.color": C_BLACK,
            "ytick.color": C_BLACK,
            "text.color": C_BLACK,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )
    return plt


def _save(fig, stem: str, alt: str, body_ref: str, paper: str) -> Dict[str, Any]:
    OUT.mkdir(parents=True, exist_ok=True)
    pdf = OUT / f"{stem}.pdf"
    png = OUT / f"{stem}.png"
    fig.savefig(pdf, bbox_inches="tight")
    fig.savefig(png, dpi=160, bbox_inches="tight")
    return {
        "id": stem,
        "paper": paper,
        "pdf": str(pdf.relative_to(ROOT)).replace("\\", "/"),
        "png": str(png.relative_to(ROOT)).replace("\\", "/"),
        "alt": alt,
        "body_ref": body_ref,
        "char_len": len(alt),
    }


def fig_ii_energy_ratio(plt) -> Dict[str, Any]:
    """R(σ;X) = (c_E c_0^2 / C_env) X^{2σ-1} for several σ > 1/2."""
    eb = _load("energy_bridge_last.json")["result"]
    c_E = float(eb.get("c_E", 0.5))
    c0 = float(eb.get("c0", 0.0415))
    C_env = float(eb.get("C_E", 1.0))
    pref = (c_E * c0 * c0) / C_env

    sigmas = [0.51, 0.60, 0.70, 0.776]
    styles = [
        (C_BLUE, "-", "o"),
        (C_TEAL, "--", "s"),
        (C_ORANGE, "-.", "^"),
        (C_RED, ":", "D"),
    ]
    Xs = [10**k for k in range(2, 13)]

    fig, ax = plt.subplots(figsize=(6.2, 4.0))
    # LOOP_REASON: STATE - draw one accessible series per sigma
    for sigma, (color, ls, mk) in zip(sigmas, styles):
        ys = [pref * (X ** (2 * sigma - 1)) for X in Xs]
        ax.loglog(
            Xs,
            ys,
            color=color,
            linestyle=ls,
            marker=mk,
            markevery=2,
            linewidth=2.0,
            markersize=5,
            label=f"sigma={sigma}",
        )
    ax.axhline(1.0, color=C_BLACK, linestyle="-", linewidth=1.2, label="R=1 threshold")
    ax.set_xlabel("X (log scale)")
    ax.set_ylabel("R(sigma; X) (log scale)")
    ax.set_title("PAPER-II: Anti-Solver energy ratio overflow")
    ax.legend(loc="lower right", frameon=True)
    ax.grid(True, which="both", linestyle=":", alpha=0.5)
    alt = (
        "Log-log plot of energy ratio R of sigma semicolon X versus X for four "
        "sigma greater than one half; all curves rise and cross R equals 1. "
        "See PAPER-II Section 4.1 and Section 5."
    )
    meta = _save(fig, "fig_ii_energy_ratio", alt, "PAPER-II §4.1–5", "II")
    plt.close(fig)
    return meta


def fig_ii_gate_fourier(plt) -> Dict[str, Any]:
    gp = _load("gate_projection_last.json")
    modes = (gp.get("fourier") or {}).get("modes") or []
    ks = [int(m["k"]) for m in modes[:12]]
    absv = [float(m["abs"]) for m in modes[:12]]
    fig, ax = plt.subplots(figsize=(6.2, 3.8))
    bars = ax.bar(
        ks,
        absv,
        color=C_BLUE,
        edgecolor=C_BLACK,
        linewidth=0.8,
        hatch="//",
        label="|a-hat(k)|",
    )
    if ks:
        bars[0].set_color(C_RED)
        bars[0].set_hatch("xx")
        bars[0].set_label("|a-hat_GATE(0)| live")
    ax.set_xlabel("Fourier mode k on Z/90Z")
    ax.set_ylabel("absolute coefficient")
    ax.set_title("PAPER-II Appendix D: GATE projection Fourier")
    ax.legend(loc="upper right")
    ax.grid(True, axis="y", linestyle=":", alpha=0.5)
    a0 = absv[0] if absv else float("nan")
    alt = (
        f"Bar chart of GATE Fourier absolute values for modes 0 to 11; "
        f"mode zero about {a0:.3f} not equal to zero, hatched differently. "
        "See PAPER-II Lemma 3.1 and Appendix D."
    )
    meta = _save(fig, "fig_ii_gate_fourier", alt, "PAPER-II Lemma 3.1 / App D", "II")
    plt.close(fig)
    return meta


def fig_ii_exponent_gap(plt) -> Dict[str, Any]:
    """Diagonal exponent 2σ vs Huxley cross exponent vs σ."""
    sigmas = [i / 100 for i in range(51, 100)]
    diag = [2 * s for s in sigmas]
    # from Huxley transfer: cross exp ≤ σ + 3(1-σ)/(2(2-σ))
    cross = [s + 3 * (1 - s) / (2 * (2 - s)) for s in sigmas]
    fig, ax = plt.subplots(figsize=(6.2, 3.8))
    ax.plot(sigmas, diag, color=C_RED, linestyle="-", marker="o", markevery=8, label="diagonal 2 sigma")
    ax.plot(sigmas, cross, color=C_BLUE, linestyle="--", marker="s", markevery=8, label="Huxley cross upper")
    ax.fill_between(sigmas, cross, diag, where=[d > c for d, c in zip(diag, cross)], color=C_TEAL, alpha=0.25, label="gap delta > 0")
    ax.set_xlabel("sigma")
    ax.set_ylabel("X-exponent")
    ax.set_title("PAPER-II: diagonal vs Huxley cross-term exponents")
    ax.legend(loc="upper left")
    ax.grid(True, linestyle=":", alpha=0.5)
    alt = (
        "Line plot comparing diagonal exponent 2 sigma (solid circles) against "
        "Huxley cross-term upper exponent (dashed squares); shaded gap where "
        "diagonal dominates for sigma greater than one half. See PAPER-II Section 4.2."
    )
    meta = _save(fig, "fig_ii_exponent_gap", alt, "PAPER-II §4.2", "II")
    plt.close(fig)
    return meta


def fig_iii_goldbach(plt) -> Dict[str, Any]:
    g = _load("goldbach_slide_last.json")
    modes = g.get("modes") or {}
    labels = ["direct", "slide"]
    vals = [int(modes.get("direct", 0)), int(modes.get("slide", 0))]
    fig, ax = plt.subplots(figsize=(5.5, 3.6))
    ax.bar(
        labels,
        vals,
        color=[C_TEAL, C_ORANGE],
        edgecolor=C_BLACK,
        hatch=["//", ".."],
    )
    ax.set_ylabel("even integers resolved")
    ax.set_title(f"PAPER-III: Goldbach cover to {g.get('limit')} (hit {g.get('hit_rate_percent')}%)")
    for i, v in enumerate(vals):
        ax.text(i, v + max(vals) * 0.01, f"{v:,}", ha="center", va="bottom", fontsize=9)
    ax.grid(True, axis="y", linestyle=":", alpha=0.5)
    alt = (
        "Bar chart of Goldbach modes to ten to the seven: all four million nine "
        "hundred ninety-nine thousand nine hundred ninety-nine evens direct, "
        "zero slide. See PAPER-III Theorem 3.1."
    )
    meta = _save(fig, "fig_iii_goldbach_modes", alt, "PAPER-III Thm 3.1", "III")
    plt.close(fig)
    return meta


def fig_iii_twin(plt) -> Dict[str, Any]:
    t = _load("twin_slide_last.json")
    fam = t.get("family_twin_counts") or {}
    labels = ["11 mod 30", "17 mod 30", "29 mod 30"]
    keys = ["11", "17", "29"]
    vals = [int(fam.get(k, 0)) for k in keys]
    markers = ["o", "s", "^"]
    colors = [C_BLUE, C_TEAL, C_ORANGE]
    fig, ax = plt.subplots(figsize=(5.5, 3.6))
    # LOOP_REASON: STATE - one accessible marker series per twin family
    for i, (lab, v, mk, col) in enumerate(zip(labels, vals, markers, colors)):
        ax.plot([i], [v], marker=mk, color=col, markersize=12, linestyle="None", label=lab)
        ax.vlines(i, 0, v, colors=col, linestyles="-", linewidth=2)
        ax.text(i, v + 8, str(v), ha="center", fontsize=9)
    ax.set_xticks(range(3), labels)
    ax.set_ylim(0, max(vals) * 1.2 if vals else 1)
    ax.set_ylabel("direct twin count")
    ax.set_title(
        f"PAPER-III: twin families to {t.get('limit')} "
        f"(cover {t.get('hit_rate_percent')}%, max|delta|={t.get('max_abs_delta')})"
    )
    ax.legend(loc="lower right")
    ax.grid(True, axis="y", linestyle=":", alpha=0.5)
    alt = (
        "Stem plot of twin counts in families 11, 17, and 29 mod 30 up to one "
        "hundred thousand; circle, square, and triangle markers; one hundred "
        "percent cover. See PAPER-III twin theorem."
    )
    meta = _save(fig, "fig_iii_twin_families", alt, "PAPER-III twin covering", "III")
    plt.close(fig)
    return meta


def fig_iv_collatz_zones(plt) -> Dict[str, Any]:
    c = _load("collatz_energy_bridge_last.json")
    z = c.get("zone_totals") or {}
    labels = ["LOCK", "GATE", "TESLA"]
    vals = [int(z.get(k, 0)) for k in labels]
    hatches = ["//", "\\\\", "xx"]
    colors = [C_BLUE, C_TEAL, C_ORANGE]
    fig, ax = plt.subplots(figsize=(5.5, 3.8))
    ax.bar(labels, vals, color=colors, edgecolor=C_BLACK, hatch=hatches)
    ax.set_yscale("log")
    ax.set_ylabel("zone visits (log scale)")
    ax.set_title(
        f"PAPER-IV: Collatz zone census to {c.get('limit')} "
        f"(mean dH={float(c.get('global_mean_dH', 0)):.4f})"
    )
    ax.grid(True, axis="y", which="both", linestyle=":", alpha=0.5)
    mean_dh = float(c.get("global_mean_dH", 0))
    alt = (
        f"Log-scale bar chart of Collatz zone visits LOCK GATE TESLA to ten to "
        f"the seven with distinct hatch patterns; mean Delta H about {mean_dh:.3f}. "
        "See PAPER-IV Theorem 3.1."
    )
    meta = _save(fig, "fig_iv_collatz_zones", alt, "PAPER-IV Thm 3.1", "IV")
    plt.close(fig)
    return meta


def fig_i_strip_ledge(plt) -> Dict[str, Any]:
    """Fixed-strip summary: (sigma, |Im s|) plane with VK curve, Ingham edge, and strip."""
    import numpy as np

    fig, ax = plt.subplots(figsize=(7.0, 4.4))
    t_max = 1.0
    # VK zero-free boundary σ(t) = 1 - c / (log^{2/3} loglog^{4/3})
    vk_c = 0.0827
    ts = np.logspace(1.0, 12.0, 200)
    sig_vk = []
    for t in ts:
        if t < 3.0:
            sig_vk.append(0.0)
            continue
        denom = (math.log(t + 3.0) ** (2.0 / 3.0)) * (
            math.log(math.log(t + 3.0) + 3.0) ** (4.0 / 3.0)
        )
        sig_vk.append(1.0 - vk_c / denom if denom > 0 else 0.0)
    t_norm = np.log10(ts) / 12.0
    ax.plot(
        sig_vk,
        t_norm,
        color=C_BLUE,
        linestyle="-",
        linewidth=2.2,
        label="VK explicit bound (c=0.0827)",
    )
    # Classical Ingham edge — dashed red
    ax.axvline(
        0.75,
        color=C_RED,
        linestyle="--",
        linewidth=2.2,
        label="Classical Ingham edge σ=3/4",
    )
    ax.axhline(0.0, color=C_BLACK, linestyle="-", linewidth=0.8)
    ax.axvline(0.5, color=C_BLACK, linestyle="-", linewidth=2.0, label="critical line Re=1/2")
    # Fixed strip (classical-computational)
    ax.axvspan(
        0.776,
        1.02,
        ymin=0.0,
        ymax=1.0,
        facecolor=C_TEAL,
        alpha=0.40,
        hatch="///",
        edgecolor=C_BLACK,
        linewidth=0.6,
        label="Fixed strip Re(s)>0.776",
    )
    # Conditional extension band (toward 1/2)
    ax.axvspan(
        0.5,
        0.776,
        ymin=0.0,
        ymax=1.0,
        facecolor=C_ORANGE,
        alpha=0.22,
        hatch="...",
        edgecolor=C_BLACK,
        linewidth=0.6,
        label="PAPER-II conditional extension",
    )
    ax.axvline(0.776, color=C_TEAL, linestyle=":", linewidth=1.6)
    ax.set_xlim(0.45, 1.02)
    ax.set_ylim(0, t_max)
    ax.set_xlabel(r"$\sigma = \operatorname{Re}(s)$", fontsize=11)
    ax.set_ylabel(r"$|\operatorname{Im}(s)|$ (log-scaled height)", fontsize=11)
    ax.set_title("Zero-free strip vs VK boundary and Ingham edge", fontsize=12)
    ax.legend(loc="upper left", fontsize=8.0, framealpha=0.92)
    for x, name in [(0.5, "1/2"), (0.75, "3/4"), (0.776, "0.776"), (1.0, "1")]:
        ax.plot([x, x], [0.02, 0.07], color=C_BLACK, linewidth=1.5)
        ax.text(x, 0.085, name, ha="center", fontsize=9, color=C_BLACK)
    ax.text(
        0.88,
        0.55,
        "zero-free\n(classical +\nPlatt $T_0$)",
        ha="center",
        va="center",
        fontsize=9,
        color=C_BLACK,
    )
    alt = (
        "Strip plot of real part versus height: blue VK curve, dashed red Ingham edge "
        "at three quarters, hatched fixed strip above 0.776. See caption and Section 5."
    )
    meta = _save(fig, "fig_i_strip_regions", alt, "PAPER-I abstract / classical strip", "I")
    plt.close(fig)
    return meta


def fig_atlas_trinity(plt) -> Dict[str, Any]:
    fig, ax = plt.subplots(figsize=(6.4, 3.0))
    boxes = [
        (0.08, "OVERFLOW\nRH I–II\nR→∞", C_RED, "//"),
        (0.38, "COVERING\nGoldbach/Twin III\n∀ resolve", C_TEAL, "\\\\"),
        (0.68, "CONTRACTION\nCollatz IV\nmean ΔH<0", C_BLUE, "xx"),
    ]
    for x, text, col, hatch in boxes:
        ax.add_patch(
            plt.Rectangle(
                (x, 0.25),
                0.24,
                0.5,
                facecolor=col,
                edgecolor=C_BLACK,
                linewidth=1.5,
                alpha=0.35,
                hatch=hatch,
                transform=ax.transAxes,
            )
        )
        ax.text(x + 0.12, 0.5, text, ha="center", va="center", transform=ax.transAxes, fontsize=10)
    ax.text(0.5, 0.08, "One GATE / LOCK / TESLA machine — Anti-Solver verifies", ha="center", transform=ax.transAxes)
    ax.axis("off")
    ax.set_title("Master Atlas: Overflow / Covering / Contraction")
    alt = (
        "Three hatched boxes labeled Overflow RH, Covering Goldbach Twin, and "
        "Contraction Collatz forming one Anti-Solver machine. See Master Atlas "
        "Section 1."
    )
    meta = _save(fig, "fig_atlas_trinity", alt, "Master Atlas §1", "0")
    plt.close(fig)
    return meta


def write_catalog(rows: List[Dict[str, Any]]) -> None:
    lines = [
        "# AMS Alt-Text Catalog — 30DFM Foundation Suite",
        "",
        "Companion to `AMS_SUBMISSION_OUTLINE.md` and DOI 10.1137/25M0010799.",
        "",
        f"**Generated:** {datetime.now(timezone.utc).isoformat()}",
        f"**Figures dir:** `flux_text/papers/figures/`",
        "",
        "## Figure inventory",
        "",
        "| ID | Paper | PDF | Alt text | Body ref |",
        "|----|-------|-----|----------|----------|",
    ]
    for r in rows:
        alt = r["alt"].replace("|", "/")
        lines.append(
            f"| `{r['id']}` | {r['paper']} | `{r['pdf']}` | {alt} | {r['body_ref']} |"
        )
    lines.extend(
        [
            "",
            "## LaTeX pattern",
            "",
            "```latex",
            r"\includegraphics[width=0.85\linewidth,alt={ALT TEXT HERE}]{figures/STEM.pdf}",
            "```",
            "",
            "## Equations",
            "",
            "Publisher uses LaTeX / MathJax speech — no author alt required for display math.",
            "",
            "Regenerate: `python scripts/generate_foundation_suite_figures.py`",
            "",
        ]
    )
    CATALOG.write_text("\n".join(lines), encoding="utf-8")


def main() -> int:
    plt = _setup_mpl()
    rows = [
        fig_atlas_trinity(plt),
        fig_i_strip_ledge(plt),
        fig_ii_energy_ratio(plt),
        fig_ii_gate_fourier(plt),
        fig_ii_exponent_gap(plt),
        fig_iii_goldbach(plt),
        fig_iii_twin(plt),
        fig_iv_collatz_zones(plt),
    ]
    man = {
        "schema": "foundation_suite_figures_v1",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "guideline_doi": "10.1137/25M0010799",
        "figures": rows,
    }
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "FIGURE_MANIFEST.json").write_text(json.dumps(man, indent=2) + "\n", encoding="utf-8")
    write_catalog(rows)
    print(json.dumps({"n_figures": len(rows), "out": str(OUT)}, indent=2))
    for r in rows:
        print(f"  {r['id']}: alt_chars={r['char_len']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

# PHI-THON STATUS: GREEN
