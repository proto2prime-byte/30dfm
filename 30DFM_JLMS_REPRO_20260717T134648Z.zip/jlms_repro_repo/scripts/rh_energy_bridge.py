#!/usr/bin/env python3
"""
Energy bridge / Anti-Solver — OB-E programme vs cited / prize_path constants.

Modes:
  programme   — optimistic explorer constants
  cited       — Ingham diagonal + MV envelope; α_eff(C_ε) foothold (0.776 strip)
  prize_path  — NT-04 Selberg–Delange α0:=0 + NT-06 Huxley cross-terms (PROGRAMME)

Prize-path honesty:
  • α0=0 removes INCOMPLETE_B2_GAP whenever R>1 at finite X.
  • At fixed X=1e12, R>1 only for σ ≳ 0.628 (energy-only edge).
  • For any fixed σ>1/2, R(X)→∞ as X→∞ (2σ−1>0). Use --asymptotic to take
    that classical large-X limit — then every σ>1/2 is ENERGY_CONTRADICTION
    *under the programme hypotheses*, not as an unconditional Clay seal.

Verdicts:
  ENERGY_CONTRADICTION       — R>1 (or asymptotic) and abscissa covered
  INCOMPLETE_B2_GAP          — R>1 but α0 too large
  NO_OBSTRUCTION_FOUND       — finite-X R≤1
  ANTI_SOLVE_OBSTRUCTION     — prize_path asymptotic: σ>1/2 under NT-04+NT-06

DR(18)=9 TESLA — energy ratio completion check.
"""
from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Literal, Optional

ROOT = Path(__file__).resolve().parents[1]
OUT_DIR = ROOT / "benchmark_outputs" / "rh_continuation"

ConstantsMode = Literal["programme", "cited", "prize_path"]

CONSTANTS: Dict[str, Dict[str, Any]] = {
    "programme": {
        "c0": 0.0415,
        "c_E": 1.0,
        "C_E": 0.85,
        "alpha0_default": None,  # use alpha_eff_from_C
        "cross_term": "montgomery_diagonal",
        "cross_term_sigma_min": 0.75,
        "label": "programme",
        "clay_hypotheses": (),
    },
    "cited": {
        "c0": 0.0415,
        "c_E": 0.5,  # Ingham diagonal
        "C_E": 1.0,  # MV envelope conservative
        "alpha0_default": None,
        "cross_term": "ingham_density",
        "cross_term_sigma_min": 0.75,
        "label": "cited (Ingham diagonal + MV envelope)",
        "clay_hypotheses": (),
    },
    "prize_path": {
        "c0": 0.0415,
        "c_E": 0.5,  # keep Ingham diagonal weight
        "C_E": 1.0,
        "alpha0_default": 0.0,  # NT-04 Selberg–Delange O(1) ⇒ Re(s)>0
        "cross_term": "huxley_density",
        "cross_term_sigma_min": 0.5,  # NT-06 programme: o(X^{2σ}) for σ>1/2
        "label": (
            "prize_path (NT-04 Selberg–Delange α0=0 + NT-06 Huxley cross-terms; "
            "PROGRAMME — hypotheses open)"
        ),
        "clay_hypotheses": (
            "selberg_delange_O1_for_a_g_mod_90",
            "huxley_cross_terms_o_X_2sigma_for_kappa7",
            "torsion_LOCK_TESLA_projects_to_energy_subspace",
        ),
    },
}


def alpha_eff_from_C(C_eps: float, mode: ConstantsMode = "cited") -> float:
    """
    Effective B2 abscissa supported by truncated C_ε (cited/programme map).
    prize_path overrides to 0 via alpha0_default (Selberg–Delange programme).
    Calibrated: C=0.074 → α≈0.546 → σ_max≈0.773 (analytics explorer).
    """
    if mode == "prize_path":
        return 0.0
    C = max(1e-6, float(C_eps))
    alpha = 0.56 - 0.58 * (C - 0.05)
    if mode == "cited":
        alpha -= 0.004
    return max(0.20, min(0.90, alpha))


def sigma_from_alpha(alpha: float) -> float:
    return 0.5 + 0.5 * float(alpha)


def alpha_needed(sigma: float) -> float:
    """Abscissa demanded by a candidate ledge σ: α = 2(σ − 1/2)."""
    return max(0.0, 2.0 * (float(sigma) - 0.5))


def energy_ratio(sigma: float, X: float, mode: ConstantsMode = "cited") -> float:
    """R = (c_E * c0^2 * X^{2σ}) / (C_E * X) = (c_E c0^2 / C_E) X^{2σ−1}."""
    c = CONSTANTS[mode]
    num = c["c_E"] * (c["c0"] ** 2) * (X ** (2.0 * sigma))
    den = c["C_E"] * X
    return num / den if den else float("inf")


def x_needed_for_ratio(sigma: float, mode: ConstantsMode = "cited", target_r: float = 1.0) -> Optional[float]:
    """Minimal X with R≥target_r (for σ>1/2). Returns None if overflow / σ≤1/2."""
    import math

    c = CONSTANTS[mode]
    pref = (c["c_E"] * (c["c0"] ** 2)) / c["C_E"]
    exp = 2.0 * float(sigma) - 1.0
    if exp <= 0 or pref <= 0:
        return None
    try:
        # log form avoids OverflowError near σ=1/2
        log_x = math.log(float(target_r) / pref) / exp
        if log_x > 700:  # exp(700) already beyond float range usefully
            return float("inf")
        return math.exp(log_x)
    except (OverflowError, ValueError):
        return float("inf")


def anti_solver(
    sigma: float,
    *,
    X: float = 1e12,
    C_eps: float = 0.074,
    mode: ConstantsMode = "cited",
    alpha0_override: float | None = None,
    asymptotic: bool = False,
) -> Dict[str, Any]:
    """
    Anti-Solver: refuse promotion until demanded abscissa ≤ working α0
    and energy lower bound beats envelope (finite X or asymptotic).
    """
    c = CONSTANTS[mode]
    alpha_demand = alpha_needed(sigma)
    if alpha0_override is not None:
        alpha0 = float(alpha0_override)
    elif c.get("alpha0_default") is not None:
        alpha0 = float(c["alpha0_default"])
    else:
        alpha0 = float(alpha_eff_from_C(C_eps, mode))

    ratio = energy_ratio(sigma, X, mode)
    covers = alpha_demand + 1e-12 >= alpha0
    cross_ok = float(sigma) + 1e-15 >= float(c.get("cross_term_sigma_min", 0.75))

    # Asymptotic: for σ>1/2, R→∞ as X→∞ under the OB-E lower-bound form.
    asymp_blocks = bool(asymptotic and float(sigma) > 0.5 + 1e-15)

    if mode == "prize_path" and asymptotic and float(sigma) > 0.5 and covers and cross_ok:
        verdict = "ANTI_SOLVE_OBSTRUCTION"
    elif (ratio > 1.0 or asymp_blocks) and covers and cross_ok:
        verdict = "ENERGY_CONTRADICTION"
    elif ratio > 1.0 and not covers:
        verdict = "INCOMPLETE_B2_GAP"
    elif asymp_blocks and not covers:
        verdict = "INCOMPLETE_B2_GAP"
    elif (ratio > 1.0 or asymp_blocks) and covers and not cross_ok:
        verdict = "CROSS_TERM_GAP"
    else:
        verdict = "NO_OBSTRUCTION_FOUND"

    return {
        "sigma": sigma,
        "X": X,
        "mode": mode,
        "asymptotic": asymptotic,
        "alpha": alpha_demand,
        "alpha0": alpha0,
        "alpha_eff_kernel": alpha_eff_from_C(C_eps, mode),
        "covers_abscissa": covers,
        "cross_term": c.get("cross_term"),
        "cross_term_sigma_min": c.get("cross_term_sigma_min"),
        "cross_term_ok": cross_ok,
        "energy_ratio": ratio,
        "X_needed_for_R1": x_needed_for_ratio(sigma, mode) if sigma > 0.5 else None,
        "C_eps": C_eps,
        "c0": c["c0"],
        "c_E": c["c_E"],
        "C_E": c["C_E"],
        "verdict": verdict,
        "rh_claim": False,
        "clay_rh_claim": False,
        "constants_label": c["label"],
        "clay_hypotheses": list(c.get("clay_hypotheses") or ()),
        "nt04_selberg_delange": mode == "prize_path",
        "nt06_huxley": mode == "prize_path",
    }


def sigma_max_from_constants(
    C_eps: float,
    *,
    mode: ConstantsMode = "cited",
    alpha0: float = 0.45,
    X: float = 1e12,
    asymptotic: bool = False,
) -> Dict[str, Any]:
    """
    Sharpest fixed-strip edge from kernel α_eff(C_ε) or prize_path α0=0.
    """
    c = CONSTANTS[mode]
    if mode == "prize_path":
        alpha_kernel = 0.0
        sigma_map = 0.5  # abscissa open down to the line (programme)
    else:
        alpha_kernel = alpha_eff_from_C(C_eps, mode)
        sigma_map = sigma_from_alpha(alpha_kernel)

    # Energy-only: minimal σ with R>1 at this X
    lo, hi = 0.5, 0.99
    energy_edge = 0.99
    # LOOP_REASON: PERFORMANCE - binary search energy edge
    for _ in range(48):
        mid = 0.5 * (lo + hi)
        if energy_ratio(mid, X, mode) > 1.0:
            energy_edge = mid
            hi = mid
        else:
            lo = mid

    # Anti-Solver sharp edge under working α0
    working_a0 = float(c["alpha0_default"]) if c.get("alpha0_default") is not None else alpha_kernel
    if alpha0 is not None and mode != "prize_path":
        # cited/programme ledge map still uses kernel; foothold α0 for diagnostics
        pass
    lo, hi = 0.5, 0.99
    anti_edge = sigma_map if mode != "prize_path" else energy_edge
    # LOOP_REASON: PERFORMANCE - binary search anti-solver edge
    for _ in range(48):
        mid = 0.5 * (lo + hi)
        r = anti_solver(
            mid,
            X=X,
            C_eps=C_eps,
            mode=mode,
            alpha0_override=working_a0 if mode == "prize_path" else alpha_kernel,
            asymptotic=asymptotic,
        )
        if r["verdict"] in ("ENERGY_CONTRADICTION", "ANTI_SOLVE_OBSTRUCTION"):
            anti_edge = mid
            hi = mid
        else:
            lo = mid

    return {
        "sigma_max": sigma_map if mode != "prize_path" else (0.5 if asymptotic else energy_edge),
        "sigma_max_anti_solver": anti_edge,
        "sigma_max_energy_only": energy_edge,
        "alpha_at_ledge": alpha_kernel,
        "alpha0_foothold": 0.0 if mode == "prize_path" else alpha0,
        "C_eps": C_eps,
        "mode": mode,
        "X": X,
        "asymptotic": asymptotic,
        "note": (
            "prize_path: α0=0; finite-X cliff ≈ energy_only; "
            "asymptotic=True ⇒ programme contradiction for all σ>1/2"
            if mode == "prize_path"
            else "cited/programme explorer ledge"
        ),
    }


def main() -> int:
    ap = argparse.ArgumentParser(description="RH energy bridge / Anti-Solver")
    ap.add_argument("--sigma", type=float, default=0.725)
    ap.add_argument("--X", type=float, default=1e12)
    ap.add_argument("--C-eps", type=float, default=0.074, dest="C_eps")
    ap.add_argument(
        "--constants",
        choices=("programme", "cited", "prize_path"),
        default="cited",
    )
    ap.add_argument("--alpha0", type=float, default=None, help="Override working α0")
    ap.add_argument(
        "--asymptotic",
        action="store_true",
        help="Take X→∞ energy limit (prize_path: all σ>1/2 obstruct under hypotheses)",
    )
    ap.add_argument("--map-ledge", action="store_true")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--ladder", action="store_true", help="Print σ ladder under current mode")
    args = ap.parse_args()

    alpha0 = args.alpha0
    # Default: kernel α_eff (cited/programme) or prize_path α0=0 — do not force 0.45.

    result = anti_solver(
        args.sigma,
        X=args.X,
        C_eps=args.C_eps,
        mode=args.constants,  # type: ignore[arg-type]
        alpha0_override=alpha0,
        asymptotic=args.asymptotic,
    )
    payload: Dict[str, Any] = {
        "ts": datetime.now(timezone.utc).isoformat(),
        "probe": "energy_bridge",
        "result": result,
    }
    if args.map_ledge:
        payload["ledge"] = sigma_max_from_constants(
            args.C_eps,
            mode=args.constants,  # type: ignore[arg-type]
            alpha0=alpha0 if alpha0 is not None else 0.45,
            X=args.X,
            asymptotic=args.asymptotic,
        )
    if args.ladder:
        ladder = []
        for s in (0.90, 0.80, 0.776, 0.725, 0.65, 0.628, 0.60, 0.55, 0.52, 0.51, 0.501):
            ladder.append(
                anti_solver(
                    s,
                    X=args.X,
                    C_eps=args.C_eps,
                    mode=args.constants,  # type: ignore[arg-type]
                    alpha0_override=alpha0,
                    asymptotic=args.asymptotic,
                )
            )
        payload["ladder"] = ladder

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    out = OUT_DIR / "energy_bridge_last.json"
    out.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    if args.json:
        print(json.dumps(payload, indent=2))
    else:
        r = result
        print(
            "energy_bridge sigma=%.4f X=%.0e  -> %s  (alpha=%.3f alpha0=%.3f ratio=%.4g mode=%s asymp=%s)"
            % (
                r["sigma"],
                r["X"],
                r["verdict"],
                r["alpha"],
                r["alpha0"],
                r["energy_ratio"],
                r["mode"],
                r["asymptotic"],
            )
        )
        if r.get("X_needed_for_R1") is not None and r["energy_ratio"] <= 1.0:
            print("  X_needed_for_R>1 ~= %.4g (finite-X energy cliff)" % r["X_needed_for_R1"])
        if "ledge" in payload:
            L = payload["ledge"]
            print(
                "  sigma_max~=%.4f  (anti~=%.4f energy_only~=%.4f)  alpha_ledge~=%.3f"
                % (L["sigma_max"], L["sigma_max_anti_solver"], L["sigma_max_energy_only"], L["alpha_at_ledge"])
            )
        if "ladder" in payload:
            print("  --- ladder ---")
            for row in payload["ladder"]:
                print(
                    "  σ=%.3f  R=%.4g  %s"
                    % (row["sigma"], row["energy_ratio"], row["verdict"])
                )
        print("  clay_rh_claim=false  Wrote %s" % out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

# PHI-THON STATUS: GREEN
