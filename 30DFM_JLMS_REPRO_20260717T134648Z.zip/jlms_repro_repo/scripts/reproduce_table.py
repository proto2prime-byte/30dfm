#!/usr/bin/env python3
"""
reproduce_table.py — One-command reproduction of the master energy-ratio table.

Usage:
  python scripts/reproduce_table.py
  python scripts/reproduce_table.py --X 1e12
  python scripts/reproduce_table.py --mode cited --X 1e12

Writes:
  benchmark_outputs/rh_continuation/reproduce_table_last.json
  (and prints a compact ASCII table to stdout)

DR(27)=9 TESLA — reproducibility completion.
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

OUT = ROOT / "benchmark_outputs" / "rh_continuation" / "reproduce_table_last.json"

# Master inequality constants (cited Ingham diagonal + MV envelope)
CONSTANTS = {
    "c_E": 0.5,
    "c0": 0.0415,
    "C_E": 1.0,
    "C_eps_cited": 0.074,
    "formula": "R(sigma, X) = (c_E * c0^2 * X^(2*sigma)) / (C_E * X)",
}


def energy_ratio(sigma: float, X: float, *, c_E: float, c0: float, C_E: float) -> float:
    return (c_E * (c0**2) * (X ** (2.0 * sigma))) / (C_E * X)


def build_table(
    *,
    X: float,
    mode: str,
    asymptotic: bool,
) -> Dict[str, Any]:
    from scripts.rh_energy_bridge import anti_solver

    sigmas = [0.90, 0.80, 0.776, 0.75, 0.725, 0.60, 0.55, 0.52, 0.501]
    rows: List[Dict[str, Any]] = []
    # LOOP_REASON: SIDE_EFFECTS - finite sigma ladder for referee table
    for sigma in sigmas:
        r = anti_solver(
            sigma,
            X=X,
            C_eps=CONSTANTS["C_eps_cited"],
            mode=mode,  # type: ignore[arg-type]
            asymptotic=asymptotic,
        )
        rows.append(
            {
                "sigma": sigma,
                "X": X,
                "R": r.get("energy_ratio"),
                "alpha": r.get("alpha"),
                "alpha0": r.get("alpha0"),
                "covers_abscissa": r.get("covers_abscissa"),
                "verdict": r.get("verdict"),
                "R_manual": energy_ratio(
                    sigma,
                    X,
                    c_E=CONSTANTS["c_E"],
                    c0=CONSTANTS["c0"],
                    C_E=CONSTANTS["C_E"],
                ),
            }
        )
    return {
        "schema": "reproduce_table_v1",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "constants": CONSTANTS,
        "mode": mode,
        "asymptotic": asymptotic,
        "X": X,
        "clay_rh_claim": False,
        "electric_slide_status": "RETRACTED",
        "rows": rows,
        "reproduce_cmd": f"python scripts/reproduce_table.py --X {X:g} --mode {mode}",
    }


def main() -> int:
    ap = argparse.ArgumentParser(description="Reproduce master R(sigma,X) table")
    ap.add_argument("--X", type=float, default=1e12)
    ap.add_argument(
        "--mode",
        choices=("cited", "prize_path", "programme"),
        default="cited",
        help="cited = PAPER-I consistency; prize_path = NT-04/NT-06 programme",
    )
    ap.add_argument("--asymptotic", action="store_true")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()

    if args.mode == "prize_path" and not args.asymptotic:
        args.asymptotic = True

    payload = build_table(X=float(args.X), mode=args.mode, asymptotic=bool(args.asymptotic))
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    if args.json:
        print(json.dumps(payload, indent=2))
    else:
        print("Master energy inequality: R(sigma,X) = (c_E c0^2 X^{2 sigma}) / (C_E X)")
        print(
            "  c_E=%s  c0=%s  C_E=%s  X=%.3g  mode=%s  asymptotic=%s"
            % (
                CONSTANTS["c_E"],
                CONSTANTS["c0"],
                CONSTANTS["C_E"],
                args.X,
                args.mode,
                args.asymptotic,
            )
        )
        print("-" * 72)
        print("%8s  %14s  %10s  %8s  %s" % ("sigma", "R(sigma,X)", "alpha", "covers", "verdict"))
        for row in payload["rows"]:
            print(
                "%8.3f  %14.6g  %10.4f  %8s  %s"
                % (
                    row["sigma"],
                    float(row["R"] or 0),
                    float(row["alpha"] or 0),
                    "Y" if row["covers_abscissa"] else "N",
                    row["verdict"],
                )
            )
        print("-" * 72)
        print("Wrote", OUT)
        print("clay_rh_claim=false  electric_slide=RETRACTED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
# PHI-THON STATUS: GREEN
