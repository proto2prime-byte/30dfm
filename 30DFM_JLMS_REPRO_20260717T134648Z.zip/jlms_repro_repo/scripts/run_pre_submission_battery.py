#!/usr/bin/env python3
"""
run_pre_submission_battery.py — Exhaustive pre-submission gauntlet for foundation suite.

Usage:
  python scripts/run_pre_submission_battery.py
  python scripts/run_pre_submission_battery.py --mode full --log benchmark_outputs/pre_submission_battery.json
  python scripts/run_pre_submission_battery.py --mode quick --skip-latex

DR(27)=9 TESLA — suite integrity before EditFlow.
"""
from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

CERT = ROOT / "benchmark_outputs" / "rh_continuation"
DEFAULT_LOG = ROOT / "benchmark_outputs" / "pre_submission_battery_last.json"

# Files scanned for retracted Electric Slide asymptotic claims
SLIDE_AUDIT_GLOBS = (
    "flux_text/papers/paper_ii_rh_prize_path.md",
    "flux_text/papers/paper_ii_rh_prize_path.tex",
    "flux_text/papers/paper_iii_gate_sieve_goldbach_twin.md",
    "flux_text/papers/paper_iii_gate_sieve_goldbach_twin.tex",
    "flux_text/papers/MASTER_ATLAS_INTRODUCTION.md",
    "flux_text/NECESSITY_BRIDGE_CLASSICAL_ZETA.md",
)


def _utc() -> str:
    return datetime.now(timezone.utc).isoformat()


def _run(
    cmd: List[str],
    *,
    timeout: int = 600,
    cwd: Optional[Path] = None,
) -> Dict[str, Any]:
    t0 = time.monotonic()
    try:
        proc = subprocess.run(
            cmd,
            cwd=str(cwd or ROOT),
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        return {
            "cmd": cmd,
            "exit_code": proc.returncode,
            "stdout_tail": (proc.stdout or "")[-4000:],
            "stderr_tail": (proc.stderr or "")[-2000:],
            "elapsed_s": round(time.monotonic() - t0, 2),
            "pass": proc.returncode == 0,
        }
    except subprocess.TimeoutExpired as exc:
        return {
            "cmd": cmd,
            "exit_code": -1,
            "stdout_tail": (exc.stdout or "")[-2000:] if exc.stdout else "",
            "stderr_tail": "TIMEOUT",
            "elapsed_s": timeout,
            "pass": False,
        }


def test_nt04_fourier_o1() -> Dict[str, Any]:
    row = _run([sys.executable, "scripts/verify_nt04_fourier_o1.py"], timeout=120)
    p = CERT / "nt04_fourier_o1_last.json"
    if p.is_file():
        data = json.loads(p.read_text(encoding="utf-8"))
        row["pass"] = bool(data.get("all_pass"))
        row["detail"] = {
            "status": data.get("status"),
            "nt04_selberg_delange": data.get("nt04_selberg_delange"),
            "alpha0": data.get("alpha0"),
        }
    row["id"] = "nt04_fourier_o1_bypass"
    return row


def test_close_classical_bridges() -> Dict[str, Any]:
    row = _run([sys.executable, "scripts/close_classical_bridges.py"], timeout=180)
    p = CERT / "classical_bridges_last.json"
    if p.is_file():
        data = json.loads(p.read_text(encoding="utf-8"))
        slots = (data.get("necessity_bridge") or {}).get("slots") or {}
        row["pass"] = slots.get("NT-04b_Selberg_Delange") == "PROVEN_FOURIER_O1"
        row["detail"] = {"slots": slots, "slide": data.get("electric_slide", {}).get("status")}
    row["id"] = "close_classical_bridges"
    return row


def test_classical_strip() -> Dict[str, Any]:
    row = _run([sys.executable, "scripts/verify_classical_strip.py"])
    p = CERT / "verify_classical_strip_last.json"
    data = json.loads(p.read_text(encoding="utf-8")) if p.is_file() else {}
    row["pass"] = bool(data.get("all_pass"))
    row["detail"] = {"all_pass": data.get("all_pass"), "sigma_fix": data.get("sigma_fix")}
    row["id"] = "classical_strip_verification"
    return row


def test_gapdr_energy_cited() -> Dict[str, Any]:
    """Cited constants, no Slide axiom — σ ladder past 3/4."""
    row = _run(
        [
            sys.executable,
            "scripts/rh_energy_bridge.py",
            "--constants",
            "cited",
            "--ladder",
            "--json",
        ],
        timeout=120,
    )
    detail: Dict[str, Any] = {"cross_ok_sigmas": [], "failures": []}
    if row["pass"]:
        p = CERT / "energy_bridge_last.json"
        if p.is_file():
            payload = json.loads(p.read_text(encoding="utf-8"))
            ladder = payload.get("ladder") or []
            for item in ladder:
                sig = float(item.get("sigma", 0))
                cross = bool(item.get("cross_term_ok", sig >= 0.75 - 1e-9))
                detail["cross_ok_sigmas"].append(
                    {"sigma": sig, "verdict": item.get("verdict"), "R": item.get("energy_ratio")}
                )
                if sig > 0.75 and not cross:
                    detail["failures"].append(f"sigma={sig} cross_term not ok")
            # Consistency: for σ>3/4, cross terms sealed in cited mode (min 0.75)
            sigmas_above = [x for x in detail["cross_ok_sigmas"] if x["sigma"] > 0.75]
            row["pass"] = len(sigmas_above) >= 3 and not detail["failures"]
    row["detail"] = detail
    row["id"] = "gapdr_energy_cited_no_slide"
    row["note"] = "Finite-X R<1 near 0.776 is expected; cross-term regime σ>0.75 is the check."
    return row


def test_b1_prime_no_slide() -> Dict[str, Any]:
    row = _run([sys.executable, "scripts/rh_b1_prime.py", "--G", "20000", "--json"])
    detail: Dict[str, Any] = {}
    if (CERT.parent / "rh_continuation").exists():
        p = list((ROOT / "benchmark_outputs" / "rh_continuation").glob("b1*last*.json"))
    p_path = ROOT / "benchmark_outputs" / "rh_continuation" / "b1_prime_last.json"
    # rh_b1_prime may write different name — parse stdout or import
    try:
        from scripts.rh_b1_prime import truncated_residual, fourier_mod90_hint

        tr = truncated_residual(20000, 0.4)
        fh = fourier_mod90_hint(5000)
        detail = {
            "C_eps_trunc": tr.get("C_eps_trunc"),
            "uniform_tail_sealed": tr.get("uniform_tail_sealed"),
            "fourier_max_AP_mean": fh.get("max_abs_AP_mean"),
            "slide_axiom_used": False,
            "pass": tr.get("uniform_tail_sealed") is False and tr.get("C_eps_trunc") is not None,
        }
        row["pass"] = bool(detail["pass"])
    except Exception as exc:
        detail = {"error": str(exc)}
        row["pass"] = False
    row["detail"] = detail
    row["id"] = "b1_prime_truncated_no_slide"
    return row


def test_goldbach_finite() -> Dict[str, Any]:
    limit = 10_000_000
    row = _run(
        [sys.executable, "scripts/goldbach_slide.py", "--limit", str(limit), "--json"],
        timeout=900,
    )
    detail: Dict[str, Any] = {}
    p = CERT / "goldbach_slide_last.json"
    if p.is_file():
        data = json.loads(p.read_text(encoding="utf-8"))
        detail = {
            "limit": data.get("limit"),
            "hit_rate_percent": data.get("hit_rate_percent"),
            "counterexamples": len(data.get("counterexamples") or []),
            "asymptotic_claim": False,
        }
        row["pass"] = (
            data.get("hit_rate_percent") == 100.0
            and not data.get("counterexamples")
        )
    row["detail"] = detail
    row["id"] = "goldbach_finite_covering"
    return row


def test_twin_finite() -> Dict[str, Any]:
    limit = 10_000_000
    row = _run(
        [sys.executable, "scripts/twin_slide.py", "--limit", str(limit), "--json"],
        timeout=900,
    )
    detail: Dict[str, Any] = {}
    p = CERT / "twin_slide_last.json"
    if p.is_file():
        data = json.loads(p.read_text(encoding="utf-8"))
        detail = {
            "limit": data.get("limit"),
            "hit_rate_percent": data.get("hit_rate_percent"),
            "misses": data.get("misses"),
            "asymptotic_claim": False,
        }
        row["pass"] = data.get("misses", 1) == 0 and data.get("hit_rate_percent") == 100.0
    row["detail"] = detail
    row["id"] = "twin_finite_covering"
    return row


def test_collatz_finite() -> Dict[str, Any]:
    limit = 10_000_000
    row = _run(
        [sys.executable, "scripts/collatz_energy_bridge.py", "--limit", str(limit), "--json"],
        timeout=900,
    )
    detail: Dict[str, Any] = {}
    p = CERT / "collatz_energy_bridge_last.json"
    if p.is_file():
        data = json.loads(p.read_text(encoding="utf-8"))
        detail = {
            "tested_to": data.get("tested_to"),
            "verdict": data.get("verdict"),
            "all_reached_1": data.get("all_reached_1"),
            "collatz_claim": data.get("collatz_claim"),
        }
        row["pass"] = (
            data.get("verdict") == "ENERGY_CONTRACTION"
            and data.get("all_reached_1") is True
            and data.get("collatz_claim") is False
        )
    row["detail"] = detail
    row["id"] = "collatz_energy_contraction"
    return row


def test_referee_verify() -> Dict[str, Any]:
    row = _run([sys.executable, "scripts/referee_verify.py", "--json"])
    p = CERT / "referee_verify_last.json"
    if p.is_file():
        data = json.loads(p.read_text(encoding="utf-8"))
        row["pass"] = bool(data.get("all_pass")) and data.get("clay_rh_claim") is False
        row["detail"] = {"all_pass": data.get("all_pass"), "clay_rh_claim": data.get("clay_rh_claim")}
    row["id"] = "referee_verify"
    return row


def test_t33_battery() -> Dict[str, Any]:
    row = _run([sys.executable, "scripts/t33_skeptic_battery.py", "--json"], timeout=120)
    p = ROOT / "benchmark_outputs" / "t33_skeptic_battery.json"
    if p.is_file():
        data = json.loads(p.read_text(encoding="utf-8"))
        sm = data.get("summary") or {}
        rate = sm.get("expected_match_rate")
        row["pass"] = rate == 1.0 and sm.get("classical_pnp_claim") is not True
        row["detail"] = {
            "expected_match_rate": rate,
            "cases_total": sm.get("cases_total"),
        }
    row["id"] = "t33_skeptic_battery"
    return row


def test_stale_json_certificates() -> Dict[str, Any]:
    """Fail if legacy Slide-axiom certificates contradict paper retraction."""
    findings: List[str] = []
    cont = CERT / "rh_continuation_last.json"
    if cont.is_file():
        data = json.loads(cont.read_text(encoding="utf-8"))
        if data.get("electric_slide_axiom") is True:
            findings.append("rh_continuation_last.json: electric_slide_axiom=true (stale)")
        if data.get("claim_tier") == "THEOREM_CONDITIONAL":
            findings.append("rh_continuation_last.json: claim_tier=THEOREM_CONDITIONAL (stale)")
        for step in data.get("steps") or []:
            if step.get("step") == "optimize_ledge":
                od = step.get("data") or {}
                if od.get("claim_tier") == "THEOREM_CONDITIONAL":
                    findings.append("rh_continuation optimize_ledge: THEOREM_CONDITIONAL (stale)")
                if od.get("uniform_tail_sealed") is True and not data.get("electric_slide_axiom_requested"):
                    pass  # NT-04 prize_path may seal tail
    antis = CERT / "rh_antisolve_battery_last.json"
    if antis.is_file():
        data = json.loads(antis.read_text(encoding="utf-8"))
        slide = (data.get("slide_scaffold") or {}).get("narrow_dr7") or {}
        note = slide.get("density_zero_note") or ""
        if "o(Y)" in note and "RETRACTED" not in note:
            findings.append("rh_antisolve slide_scaffold: o(Y) without RETRACTED label")
    return {
        "id": "stale_json_slide_audit",
        "pass": len(findings) == 0,
        "findings": findings,
    }


def test_optimize_ledge_no_slide_axiom() -> Dict[str, Any]:
    row = _run(
        [
            sys.executable,
            "scripts/optimize_ledge.py",
            "--target",
            "0.776",
            "--constants",
            "cited",
            "--json",
        ],
        timeout=120,
    )
    detail: Dict[str, Any] = {"electric_slide_axiom": False}
    opt = CERT / "optimize_ledge_last.json"
    if opt.is_file():
        od = json.loads(opt.read_text(encoding="utf-8"))
        detail["claim_tier"] = od.get("claim_tier")
        if od.get("claim_tier") == "THEOREM_CONDITIONAL":
            row["pass"] = False
    row["detail"] = detail
    row["id"] = "optimize_ledge_no_slide_axiom"
    return row


def audit_slide_references() -> Dict[str, Any]:
    """Flag asymptotic Slide claims; allow retraction / finite GATE wording."""
    bad_patterns = [
        re.compile(r"\|\s*E\s*\(\s*Y\s*\)\s*\|\s*=\s*o\s*\(\s*Y\s*\)", re.I),
        re.compile(r"all but\s+o\s*\(\s*Y\s*\)", re.I),
        re.compile(r"density-zero lemma", re.I),
        re.compile(r"asymptotic_seal\s*:\s*true", re.I),
        re.compile(r"SEALED_ASYMPTOTIC", re.I),
    ]
    ok_patterns = [
        re.compile(r"retract", re.I),
        re.compile(r"RETRACTED", re.I),
        re.compile(r"false by parity", re.I),
        re.compile(r"finite", re.I),
        re.compile(r"GATE offset", re.I),
    ]
    findings: List[Dict[str, Any]] = []
    for rel in SLIDE_AUDIT_GLOBS:
        path = ROOT / rel.replace("/", "\\")
        if not path.is_file():
            continue
        text = path.read_text(encoding="utf-8", errors="replace")
        for i, line in enumerate(text.splitlines(), 1):
            if not any(p.search(line) for p in bad_patterns):
                continue
            if any(p.search(line) for p in ok_patterns):
                continue
            findings.append({"file": rel, "line": i, "snippet": line.strip()[:120]})
    return {
        "id": "paper_ii_iii_slide_audit",
        "pass": len(findings) == 0,
        "findings": findings,
        "scanned": list(SLIDE_AUDIT_GLOBS),
    }


def test_latex_build(*, skip: bool) -> Dict[str, Any]:
    if skip:
        return {"id": "latex_build", "pass": None, "skipped": True}
    row = _run([sys.executable, "scripts/build_jlms_submission_pdfs.py"], timeout=300)
    pdf = ROOT / "benchmark_outputs" / "jlms_submission" / "paper_i_fixed_strip_0776.pdf"
    latex_ok = "LaTeX" in (row.get("stdout_tail") or "") and row.get("pass")
    row["pass"] = pdf.is_file() and pdf.stat().st_size > 50_000 and (latex_ok or pdf.stat().st_size > 200_000)
    row["detail"] = {"pdf": str(pdf), "size": pdf.stat().st_size if pdf.is_file() else 0}
    row["id"] = "latex_build"
    return row


def test_unsolved_toc() -> Dict[str, Any]:
    row = _run([sys.executable, "scripts/unsolved_problems_suite.py", "--no-md"], timeout=120)
    p = ROOT / "benchmark_outputs" / "unsolved_problems_analysis.json"
    detail: Dict[str, Any] = {}
    if p.is_file():
        data = json.loads(p.read_text(encoding="utf-8"))
        detail["millennium_claims"] = (data.get("summary") or {}).get("millennium_claims")
        rh = next((x for x in data.get("problems", []) if x.get("id") == "UP-RH-01"), {})
        detail["rh_millennium_claim"] = rh.get("millennium_claim")
        row["pass"] = detail.get("millennium_claims") == 0 and rh.get("millennium_claim") is False
    row["detail"] = detail
    row["id"] = "unsolved_problems_toc"
    return row


def run_battery(*, mode: str, skip_latex: bool) -> Dict[str, Any]:
    tests: List[Any] = [
        test_classical_strip,
        test_nt04_fourier_o1,
        test_gapdr_energy_cited,
        test_b1_prime_no_slide,
        test_referee_verify,
        test_close_classical_bridges,
        test_t33_battery,
        test_optimize_ledge_no_slide_axiom,
        test_stale_json_certificates,
        lambda: audit_slide_references(),
        test_unsolved_toc,
    ]
    if mode == "full":
        tests.extend([test_goldbach_finite, test_twin_finite, test_collatz_finite])
    tests.append(lambda: test_latex_build(skip=skip_latex))

    results: List[Dict[str, Any]] = []
    for fn in tests:
        name = getattr(fn, "__name__", "audit")
        print(f"[battery] {name} ...", flush=True)
        try:
            row = fn() if callable(fn) else fn
        except Exception as exc:
            row = {"id": name, "pass": False, "error": str(exc)}
        results.append(row)
        status = "PASS" if row.get("pass") is True else ("SKIP" if row.get("skipped") else "FAIL")
        print(f"  -> {status}  ({row.get('id', name)})", flush=True)

    passed = sum(1 for r in results if r.get("pass") is True)
    failed = sum(1 for r in results if r.get("pass") is False)
    skipped = sum(1 for r in results if r.get("pass") is None)
    return {
        "schema": "pre_submission_battery_v1",
        "generated_at_utc": _utc(),
        "mode": mode,
        "summary": {
            "passed": passed,
            "failed": failed,
            "skipped": skipped,
            "total": len(results),
            "all_pass": failed == 0,
        },
        "electric_slide_status": "RETRACTED",
        "clay_rh_claim": False,
        "tests": results,
    }


def main() -> int:
    ap = argparse.ArgumentParser(description="Pre-submission gauntlet for foundation suite")
    ap.add_argument("--mode", choices=("quick", "full"), default="full")
    ap.add_argument("--log", type=Path, default=DEFAULT_LOG)
    ap.add_argument("--skip-latex", action="store_true")
    args = ap.parse_args()

    report = run_battery(mode=args.mode, skip_latex=args.skip_latex)
    args.log.parent.mkdir(parents=True, exist_ok=True)
    args.log.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report["summary"], indent=2))
    print(f"Wrote {args.log}")
    return 0 if report["summary"]["all_pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
# PHI-THON STATUS: GREEN
