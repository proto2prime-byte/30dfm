#!/usr/bin/env python3
"""
certify_bridge_appendix.py — One-shot NT-04 + NT-06 + master inequality certificate.

DR(36)=9 TESLA — bridge appendix completion.
"""
from __future__ import annotations

import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "benchmark_outputs" / "rh_continuation" / "bridge_appendix_last.json"


def _run(script: str) -> Dict[str, Any]:
    r = subprocess.run(
        [sys.executable, str(ROOT / "scripts" / script)],
        cwd=str(ROOT),
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=600,
    )
    return {"script": script, "exit_code": r.returncode, "stdout_tail": (r.stdout or "")[-400:]}


def main() -> int:
    steps = [
        _run("certify_nt04_explicit.py"),
        _run("certify_nt06_delta.py"),
        _run("reproduce_table.py"),
        _run("verify_gate_projection.py"),
    ]
    nt04 = json.loads(
        (ROOT / "benchmark_outputs/rh_continuation/nt04_explicit_last.json").read_text(encoding="utf-8")
    )
    nt06 = json.loads(
        (ROOT / "benchmark_outputs/rh_continuation/nt06_delta_last.json").read_text(encoding="utf-8")
    )
    table = json.loads(
        (ROOT / "benchmark_outputs/rh_continuation/reproduce_table_last.json").read_text(encoding="utf-8")
    )
    gate = {}
    gp = ROOT / "benchmark_outputs/rh_continuation/gate_projection_last.json"
    if gp.is_file():
        gate = json.loads(gp.read_text(encoding="utf-8"))

    a0 = None
    fourier = gate.get("fourier") or {}
    if "modes" in fourier and fourier["modes"]:
        a0 = fourier["modes"][0].get("abs")
    a0 = a0 or (fourier.get("a_hat_P_GATE_0") or {}).get("abs")

    all_pass = (
        nt04.get("all_pass")
        and nt06.get("all_pass")
        and nt04.get("C_eps_tail", 1) <= 0.07 + 1e-12
        and float(a0 or 0) > 0
        and all(s["exit_code"] == 0 for s in steps)
    )

    payload: Dict[str, Any] = {
        "schema": "bridge_appendix_v1",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "docs": [
            "flux_text/NT04_REFEREE_LEMMA.md",
            "flux_text/NT06_REFEREE_LEMMA.md",
            "flux_text/APPENDIX_MASTER_INEQUALITY_NT04_NT06.md",
        ],
        "steps": steps,
        "nt04": {
            "status": nt04.get("status"),
            "B": nt04.get("B"),
            "Y0": nt04.get("Y0"),
            "C_eps_tail": nt04.get("C_eps_tail"),
            "C_eps_trunc": nt04.get("C_eps_trunc"),
            "all_pass": nt04.get("all_pass"),
        },
        "nt06": {
            "status": nt06.get("status"),
            "example_0725_delta": (nt06.get("example_sigma_0725") or {}).get("delta_huxley"),
            "all_delta_positive": nt06.get("all_delta_positive_on_ladder"),
            "all_pass": nt06.get("all_pass"),
        },
        "P_GATE_a_hat_0": a0,
        "energy_table_rows": len(table.get("rows") or []),
        "master_inequality": "R(sigma,X)=(c_E c0^2/C_E) X^{2sigma-1}",
        "clay_rh_claim": False,
        "electric_slide_status": "RETRACTED",
        "all_pass": all_pass,
        "status": "BRIDGE_APPENDIX_SEALED" if all_pass else "INCOMPLETE",
    }
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(
        "certify_bridge_appendix  status=%s  all_pass=%s  C_tail=%s  delta_0725=%s"
        % (
            payload["status"],
            all_pass,
            payload["nt04"]["C_eps_tail"],
            payload["nt06"]["example_0725_delta"],
        )
    )
    print(" ->", OUT)
    return 0 if all_pass else 1


if __name__ == "__main__":
    raise SystemExit(main())
# PHI-THON STATUS: GREEN
