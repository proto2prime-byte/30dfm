#!/usr/bin/env python3
"""
goldbach_slide — Electric Slide reduction for Goldbach (sieve-accelerated).

Structural claim: every even n is a sum of two primes, searched preferentially
via STONE residues; if complement is STONE-composite, apply Electric Slide.

Tracks max |delta| used by Slide witnesses. Not a Goldbach proof.

DR(18)=9 TESLA — Goldbach slide completion signature.
"""
from __future__ import annotations

import argparse
import json
import math
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from electric_slide_prime_finder import (  # noqa: E402
    GATE_OFFSETS,
    STONE_R30,
    WIDE_OFFSETS,
    slide_composite,
)

OUT_DIR = ROOT / "benchmark_outputs" / "rh_continuation"


def sieve_primes(limit: int) -> List[int]:
    """Eratosthenes up to limit inclusive."""
    limit = int(limit)
    if limit < 2:
        return []
    n = limit + 1
    is_p = bytearray(b"\x01") * n
    is_p[0:2] = b"\x00\x00"
    # LOOP_REASON: PERFORMANCE - classical sieve
    for i in range(2, int(math.isqrt(limit)) + 1):
        if is_p[i]:
            step = i
            start = i * i
            is_p[start:n:step] = b"\x00" * (((n - 1 - start) // step) + 1)
    return [i for i in range(2, n) if is_p[i]]


def goldbach_slide(
    n: int,
    *,
    wide: bool = False,
    primes: Optional[List[int]] = None,
    prime_set: Optional[Set[int]] = None,
) -> Dict[str, Any]:
    n = int(n)
    if n < 4 or n % 2:
        return {"n": n, "ok": False, "reason": "need even n>=4"}

    if primes is None:
        primes = sieve_primes(n)
    if prime_set is None:
        prime_set = set(primes)

    offsets = WIDE_OFFSETS if wide else GATE_OFFSETS
    # Pass 1: classical direct Goldbach (prefer true prime+prime)
    # LOOP_REASON: EARLY_EXIT - first direct witness wins
    for p in primes:
        if p > n // 2:
            break
        q = n - p
        if q in prime_set:
            return {
                "n": n,
                "ok": True,
                "p": p,
                "q": q,
                "mode": "direct",
                "delta": 0,
                "abs_delta": 0,
                "p_r30": p % 30,
                "q_r30": q % 30,
            }

    # Pass 2: Electric Slide on STONE complements
    # LOOP_REASON: EARLY_EXIT - first slide witness wins
    for p in primes:
        if p > n // 2:
            break
        q = n - p
        if q <= 5 or (q % 30) not in STONE_R30:
            continue
        hits = slide_composite(q, wide=wide)
        if hits:
            delta, q2 = hits[0]
            p2 = n - q2
            if p2 in prime_set:
                return {
                    "n": n,
                    "ok": True,
                    "p": p2,
                    "q": q2,
                    "mode": "slide",
                    "slide_from": q,
                    "delta": int(delta),
                    "abs_delta": abs(int(delta)),
                }
    return {"n": n, "ok": False, "reason": "no_witness", "wide": wide}


def certify_range(limit: int, *, wide: bool = False, sample_fail: int = 20) -> Dict[str, Any]:
    primes = sieve_primes(limit)
    prime_set = set(primes)
    tested = 0
    ok = 0
    fails: List[int] = []
    modes = {"direct": 0, "slide": 0}
    max_abs_delta = 0
    delta_hist: Dict[int, int] = {}
    # LOOP_REASON: STATE - Goldbach census on evens
    for n in range(4, limit + 1, 2):
        tested += 1
        r = goldbach_slide(n, wide=wide, primes=primes, prime_set=prime_set)
        if r.get("ok"):
            ok += 1
            mode = r.get("mode", "direct")
            modes[mode] = modes.get(mode, 0) + 1
            ad = int(r.get("abs_delta") or abs(int(r.get("delta") or 0)))
            if ad > max_abs_delta:
                max_abs_delta = ad
            if mode == "slide":
                delta_hist[ad] = delta_hist.get(ad, 0) + 1
        elif len(fails) < sample_fail:
            fails.append(n)
    return {
        "ts": datetime.now(timezone.utc).isoformat(),
        "probe": "goldbach_slide",
        "limit": limit,
        "wide": wide,
        "evens_tested": tested,
        "resolved": ok,
        "hit_rate_percent": 100.0 * ok / max(1, tested),
        "modes": modes,
        "max_abs_delta": max_abs_delta,
        "slide_delta_hist": dict(sorted(delta_hist.items())),
        "fail_sample": fails,
        "reduction": "STONE + Electric Slide on complement",
        "claim": "empirical_reduction_not_proof",
        "rh_claim": False,
    }


def main() -> int:
    ap = argparse.ArgumentParser(description="Goldbach Electric Slide reduction")
    ap.add_argument("--n", type=int, help="Single even n")
    ap.add_argument("--limit", type=int, default=10000, help="Certify all even n <= limit")
    ap.add_argument("--wide-offsets", action="store_true")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()

    if args.n:
        result: Any = goldbach_slide(args.n, wide=args.wide_offsets)
    else:
        result = certify_range(args.limit, wide=args.wide_offsets)

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    out = OUT_DIR / "goldbach_slide_last.json"
    out.write_text(json.dumps(result, indent=2), encoding="utf-8")

    if args.json:
        print(json.dumps(result, indent=2))
    else:
        if args.n:
            print("goldbach_slide n=%d -> %s" % (args.n, result))
        else:
            print(
                "GOLDBACH_SLIDE  limit=%d  hit=%.3f%%  (%d/%d)  modes=%s  max|delta|=%s"
                % (
                    result["limit"],
                    result["hit_rate_percent"],
                    result["resolved"],
                    result["evens_tested"],
                    result["modes"],
                    result.get("max_abs_delta"),
                )
            )
            if result.get("slide_delta_hist"):
                print("  slide_delta_hist:", result["slide_delta_hist"])
            if result["fail_sample"]:
                print("  fail_sample:", result["fail_sample"][:10])
        print("  Wrote %s" % out)
    return 0 if (args.n and result.get("ok")) or (not args.n and result.get("hit_rate_percent", 0) >= 99.0) else 1


if __name__ == "__main__":
    raise SystemExit(main())

# PHI-THON STATUS: GREEN
