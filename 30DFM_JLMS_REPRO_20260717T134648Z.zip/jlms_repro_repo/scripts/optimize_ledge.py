#!/usr/bin/env python3
"""
optimize_ledge — finite-diff explorer for the fixed zero-free strip.

Rebuilt from flux_text/rh_analytics.txt (machine-loss recovery).
Maps (C_ε, α0, OB-E constants) ↔ σ_max. Does not seal RH.

CLI (standalone):
  python scripts/optimize_ledge.py --target 0.725 --epsilon 0.4 --G 20000 --interval --constants cited

Also callable as a library from rh_continuation_harness.

DR(36)=9 TESLA — ledge explorer completion signature.
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.rh_b1_prime import truncated_residual  # noqa: E402
from scripts.rh_energy_bridge import anti_solver, sigma_max_from_constants  # noqa: E402

OUT_DIR = ROOT / "benchmark_outputs" / "rh_continuation"


def optimize_ledge(
    target_sigma: float = 0.725,
    epsilon: float = 0.4,
    G: int = 20000,
    learning_rate: float = 0.01,
    max_iter: int = 50,
    *,
    interval: bool = True,
    constants: str = "cited",
    X: float = 1e12,
    alpha0: float = 0.45,
    electric_slide_axiom: bool = False,
) -> Dict[str, Any]:
    """
    1. Estimate C_ε^trunc on [1,G]
    2. Map to sigma_max via energy bridge + B2 gate
    3. Finite-diff nudge of effective C_ε toward covering target
    4. Report band + bottleneck

    If electric_slide_axiom: treat uniform tail as sealed at trunc C
    (LEMMA_B1_PRIME Electric Slide → THEOREM_CONDITIONAL).
    """
    trunc = truncated_residual(G, epsilon)
    C = float(trunc["C_eps_trunc"])
    band = list(trunc["band"]) if interval else [C, C]

    history: List[Dict[str, Any]] = []
    C_work = C
    converged = False
    sigma_max = 0.5

    # LOOP_REASON: STATE - finite-diff explorer iterations
    for i in range(1, max_iter + 1):
        ledge = sigma_max_from_constants(
            C_work, mode=constants, alpha0=alpha0, X=X  # type: ignore[arg-type]
        )
        sigma_max = float(ledge["sigma_max"])
        loss = max(0.0, float(target_sigma) - sigma_max)
        step = {
            "iter": i,
            "C_eps": C_work,
            "sigma_max": sigma_max,
            "loss": loss,
            "alpha": ledge["alpha_at_ledge"],
        }
        history.append(step)
        if loss <= 1e-6:
            converged = True
            break
        # Gradient proxy: lowering C_ε raises ledge; nudge toward covering target
        # d(sigma)/d(C) ≈ -0.35 empirically from analytics sensitivity
        grad = -0.35
        C_work = max(1e-4, C_work + learning_rate * grad * loss * 10.0)

    # Final certificate under original trunc (honest) and under explorer C_work
    final_orig = sigma_max_from_constants(
        C, mode=constants, alpha0=alpha0, X=X  # type: ignore[arg-type]
    )
    probe_target = anti_solver(
        target_sigma,
        X=X,
        C_eps=C,
        mode=constants,  # type: ignore[arg-type]
        alpha0_override=alpha0,
    )

    covered = final_orig["sigma_max"] + 1e-9 >= target_sigma
    if electric_slide_axiom:
        # Retracted lemma — flag only for historical explorer runs; never a theorem tier.
        bottleneck = "electric_slide_RETRACTED"
        claim_tier = "RETRACTED_HEURISTIC"
        uniform_tail_sealed = False
        note = (
            "RETRACTED_HEURISTIC: --electric-slide-axiom is deprecated. "
            "Asymptotic |E(Y)|=o(Y) is false (parity/PNT). Use NT-04 Fourier O(1) instead."
        )
    else:
        nt04_path = ROOT / "benchmark_outputs" / "rh_continuation" / "nt04_fourier_o1_last.json"
        nt04_ok = nt04_path.is_file() and json.loads(nt04_path.read_text(encoding="utf-8")).get("all_pass")
        if nt04_ok and constants == "prize_path":
            bottleneck = "none" if covered else "huxley_nt06_programme"
            claim_tier = "THEOREM_PROGRAMME_NT04"
            uniform_tail_sealed = True
            note = (
                "NT-04 Fourier O(1) verified (no Electric Slide). "
                "Prize-path asymptotic covers all sigma>1/2 under NT-06 programme; clay_rh_claim=false."
            )
        else:
            bottleneck = "uniform_tail"
            if not covered:
                if probe_target["verdict"] == "INCOMPLETE_B2_GAP":
                    bottleneck = "B2_abscissa"
                elif probe_target["verdict"] == "NO_OBSTRUCTION_FOUND":
                    bottleneck = "energy_ratio_or_constants"
                else:
                    bottleneck = "uniform_tail_or_C_eps"
            claim_tier = "EXPLORER_MAP"
            uniform_tail_sealed = False
            note = (
                "Programme/cited map only. Run verify_nt04_fourier_o1.py for NT-04 bypass; "
                "Electric Slide axiom is RETRACTED."
            )

    return {
        "ts": datetime.now(timezone.utc).isoformat(),
        "probe": "optimize_ledge",
        "target": target_sigma,
        "epsilon": epsilon,
        "G": G,
        "constants": constants,
        "alpha0": alpha0,
        "electric_slide_axiom": electric_slide_axiom,
        "C_eps_trunc": C,
        "C_eps_explorer": C_work,
        "C_eps_tail_assumed": C if electric_slide_axiom else None,
        "band": band,
        "certified_proxy": bool(interval and trunc.get("certified_proxy")),
        "sigma_max": final_orig["sigma_max"],
        "sigma_max_explorer_path": sigma_max,
        "loss": max(0.0, target_sigma - final_orig["sigma_max"]),
        "converged": converged or covered,
        "target_verdict": probe_target["verdict"],
        "bottleneck": bottleneck,
        "uniform_tail_sealed": uniform_tail_sealed,
        "claim_tier": claim_tier,
        "rh_claim": False,
        "massless": False,
        "history": history[:20],
        "note": note,
    }


def main() -> int:
    ap = argparse.ArgumentParser(description="RH optimize_ledge explorer")
    ap.add_argument("--target", type=float, default=0.725)
    ap.add_argument("--epsilon", type=float, default=0.4)
    ap.add_argument("--G", type=int, default=20000)
    ap.add_argument("--learning_rate", type=float, default=0.01)
    ap.add_argument("--max_iter", type=int, default=50)
    ap.add_argument("--interval", action="store_true", default=True)
    ap.add_argument("--no-interval", action="store_true")
    ap.add_argument("--constants", choices=("programme", "cited", "prize_path"), default="cited")
    ap.add_argument("--X", type=float, default=1e12)
    ap.add_argument("--alpha0", type=float, default=0.45)
    ap.add_argument(
        "--electric-slide-axiom",
        action="store_true",
        help="Assume Electric Slide seals uniform tail at trunc C (THEOREM_CONDITIONAL)",
    )
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()

    result = optimize_ledge(
        target_sigma=args.target,
        epsilon=args.epsilon,
        G=args.G,
        learning_rate=args.learning_rate,
        max_iter=args.max_iter,
        interval=not args.no_interval,
        constants=args.constants,
        X=args.X,
        alpha0=args.alpha0,
        electric_slide_axiom=args.electric_slide_axiom,
    )

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    out = OUT_DIR / "optimize_ledge_last.json"
    out.write_text(json.dumps(result, indent=2), encoding="utf-8")

    if args.json:
        print(json.dumps(result, indent=2))
    else:
        print(
            "OPTIMIZE_LEDGE  target=%.3f  sigma_max~=%.3f  loss=%.4g  converged=%s"
            % (result["target"], result["sigma_max"], result["loss"], result["converged"])
        )
        print(
            "  C_eps~=%.4f  alpha0~=%.2f  band=[%.4f, %.4f]  axiom=%s"
            % (
                result["C_eps_trunc"],
                result["alpha0"],
                result["band"][0],
                result["band"][1],
                result["electric_slide_axiom"],
            )
        )
        print(
            "  claim_tier=%s  bottleneck=%s  rh_claim=%s"
            % (result["claim_tier"], result["bottleneck"], result["rh_claim"])
        )
        print("  Wrote %s" % out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

# PHI-THON STATUS: GREEN
