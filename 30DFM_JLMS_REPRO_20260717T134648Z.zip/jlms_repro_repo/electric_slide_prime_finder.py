#!/usr/bin/env python3
"""
Electric Slide Prime Finder
---------------------------
Implements Greg's digit-split product boundary search:
for prime p, split digits -> product -> probe offsets around product.
"""
from __future__ import annotations

import argparse
from datetime import datetime
from pathlib import Path

try:
    from prime_laws import is_prime
except Exception:
    def is_prime(n: int) -> bool:
        if n < 2:
            return False
        if n in (2, 3):
            return True
        if n % 2 == 0:
            return False
        d = 3
        while d * d <= n:
            if n % d == 0:
                return False
            d += 2
        return True


OFFSETS = (-2, -1, 1, 2, 4, 6)
# GATE-zone offsets used by the B1' composite lemma (narrow)
GATE_OFFSETS = OFFSETS
# Strategy B: GATE+LOCK offsets avoiding multiples of 3
WIDE_OFFSETS = (-16, -14, -10, -8, -6, -4, -2, -1, 1, 2, 4, 6, 8, 10, 14, 16)
STONE_R30 = (1, 7, 11, 13, 17, 19, 23, 29)


def digital_root(n: int) -> int:
    n = abs(int(n))
    if n == 0:
        return 0
    return 1 + (n - 1) % 9


def electric_slide(p: int):
    """Digit-split product probe (legacy Greg finder)."""
    s = str(abs(int(p)))
    found = []
    for i in range(1, len(s)):
        left, right = int(s[:i]), int(s[i:])
        product = left * right
        for offset in OFFSETS:
            candidate = product + offset
            if candidate > 1 and is_prime(candidate):
                found.append((f"{left}x{right}", product, offset, candidate))
    return found


def slide_composite(n: int, *, wide: bool = False):
    """
    Electric Slide Lemma probe: for composite n coprime to 30,
    try GATE (or GATE+LOCK wide) offsets; return hits where n+delta is prime.
    DR(27)=9 TESLA — lemma probe completion.
    """
    n = int(n)
    if n < 2 or is_prime(n):
        return []
    if n % 2 == 0 or n % 3 == 0 or n % 5 == 0:
        return []
    if (n % 30) not in STONE_R30:
        return []
    offsets = WIDE_OFFSETS if wide else GATE_OFFSETS
    hits = []
    for delta in offsets:
        cand = n + delta
        if cand > 1 and is_prime(cand):
            hits.append((delta, cand))
    return hits


def classify_miss(n: int) -> str:
    """Rough structural tag for Slide misses (square / semiprime / other)."""
    if int(n**0.5) ** 2 == n:
        return "square"
    # trial factor for semiprime hint
    d = 3
    factors = []
    m = n
    while d * d <= m and len(factors) < 3:
        if m % d == 0:
            factors.append(d)
            m //= d
            while m % d == 0:
                m //= d
        d += 2
    if m > 1:
        factors.append(m)
    if len(factors) == 2:
        return "semiprime"
    if len(factors) >= 3:
        return "multiprime"
    return "other"


def composite_slide_census(limit: int, *, dr7_only: bool = False, wide: bool = False) -> dict:
    """
    Census for the formal lemma: composites in STONE residues (optionally DR7 / ==16 mod 18).
    """
    limit = int(limit)
    tested = 0
    hits = 0
    miss_sample = []
    miss_tags = {"square": 0, "semiprime": 0, "multiprime": 0, "other": 0}
    # LOOP_REASON: STATE - composite census up to limit
    for n in range(7, limit + 1):
        if n % 2 == 0 or n % 3 == 0 or n % 5 == 0:
            continue
        if (n % 30) not in STONE_R30:
            continue
        if is_prime(n):
            continue
        if dr7_only and not (n % 18 == 16 or digital_root(n) == 7):
            continue
        tested += 1
        found = slide_composite(n, wide=wide)
        if found:
            hits += 1
        else:
            tag = classify_miss(n)
            miss_tags[tag] = miss_tags.get(tag, 0) + 1
            if len(miss_sample) < 20:
                miss_sample.append({"n": n, "tag": tag})
    rate = 100.0 * hits / max(1, tested)
    return {
        "limit": limit,
        "dr7_only": dr7_only,
        "wide_offsets": wide,
        "offset_set": list(WIDE_OFFSETS if wide else GATE_OFFSETS),
        "composites_tested": tested,
        "composites_with_hit": hits,
        "hit_rate_percent": rate,
        "miss_sample": miss_sample,
        "miss_tags": miss_tags,
        "density_zero_note": (
            "RETRACTED_HEURISTIC: finite-window hit rates only; asymptotic |E(Y)|=o(Y) is false "
            "(parity/PNT; see PAPER-I §4). Misses often squares/semiprimes."
        ),
        "lemma": "Electric Slide (composite GATE offset — finite sieve only)",
        "asymptotic_status": "RETRACTED",
    }


def primes_upto(limit: int):
    for n in range(2, int(limit) + 1):
        if is_prime(n):
            yield n


def main() -> int:
    ap = argparse.ArgumentParser(description="Electric Slide prime boundary finder")
    ap.add_argument("--prime", type=int, help="Run electric slide for one prime")
    ap.add_argument("--test-range", type=int, default=100000, help="Test all primes up to this value")
    ap.add_argument("--composite-census", type=int, metavar="LIMIT",
                    help="Census Electric Slide lemma on STONE composites up to LIMIT")
    ap.add_argument("--dr7-only", action="store_true", help="With --composite-census, restrict to DR7 / 16 mod 18")
    ap.add_argument("--wide-offsets", action="store_true",
                    help="Use GATE+LOCK wide offset budget (Strategy B)")
    ap.add_argument("--report", action="store_true", help="Write report in flux_text/electric_slide_reports")
    args = ap.parse_args()

    if args.composite_census:
        cens = composite_slide_census(
            args.composite_census, dr7_only=args.dr7_only, wide=args.wide_offsets
        )
        print("Electric Slide COMPOSITE lemma census")
        print(f"  limit: {cens['limit']}  dr7_only: {cens['dr7_only']}  wide: {cens['wide_offsets']}")
        print(f"  composites_tested: {cens['composites_tested']}")
        print(f"  composites_with_hit: {cens['composites_with_hit']}")
        print(f"  hit_rate_percent: {cens['hit_rate_percent']:.6f}")
        print(f"  miss_tags: {cens['miss_tags']}")
        if cens["miss_sample"]:
            print(f"  miss_sample: {cens['miss_sample'][:8]}")
        if args.report:
            out_dir = Path(__file__).resolve().parent / "flux_text" / "electric_slide_reports"
            out_dir.mkdir(parents=True, exist_ok=True)
            stamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
            out = out_dir / f"electric_slide_composite_{stamp}.txt"
            out.write_text(
                "\n".join(f"{k}: {v}" for k, v in cens.items()) + "\n",
                encoding="utf-8",
            )
            print(f"report: {out}")
        return 0

    lines = []
    lines.append("ELECTRIC SLIDE PRIME FINDER REPORT")
    lines.append("=" * 60)

    if args.prime:
        p = int(args.prime)
        hits = electric_slide(p)
        print(f"Prime {p} -> {len(hits)} hits")
        for row in hits[:40]:
            print(f"  split={row[0]} product={row[1]} offset={row[2]:+d} candidate={row[3]}")
        lines.append(f"single_prime: {p}")
        lines.append(f"hit_count: {len(hits)}")
        lines.extend([f"hit: split={r[0]} product={r[1]} offset={r[2]:+d} candidate={r[3]}" for r in hits[:200]])
    else:
        limit = int(args.test_range)
        total_primes = 0
        primes_with_hits = 0
        total_hits = 0
        sample = []
        for p in primes_upto(limit):
            total_primes += 1
            hits = electric_slide(p)
            if hits:
                primes_with_hits += 1
                total_hits += len(hits)
                if len(sample) < 30:
                    sample.append((p, hits[:3]))
        hit_rate = (100.0 * primes_with_hits / max(1, total_primes))
        avg_hits = (total_hits / max(1, primes_with_hits))
        print("Electric Slide test-range summary")
        print(f"  limit: {limit}")
        print(f"  primes_tested: {total_primes}")
        print(f"  primes_with_hits: {primes_with_hits}")
        print(f"  hit_rate_percent: {hit_rate:.3f}")
        print(f"  avg_hits_when_positive: {avg_hits:.3f}")
        lines.append(f"limit: {limit}")
        lines.append(f"primes_tested: {total_primes}")
        lines.append(f"primes_with_hits: {primes_with_hits}")
        lines.append(f"hit_rate_percent: {hit_rate:.6f}")
        lines.append(f"avg_hits_when_positive: {avg_hits:.6f}")
        lines.append("sample:")
        for p, rows in sample:
            lines.append(f"  p={p}")
            for r in rows:
                lines.append(f"    split={r[0]} product={r[1]} offset={r[2]:+d} candidate={r[3]}")

    if args.report:
        out_dir = Path(__file__).resolve().parent / "flux_text" / "electric_slide_reports"
        out_dir.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        out = out_dir / f"electric_slide_{stamp}.txt"
        out.write_text("\n".join(lines) + "\n", encoding="utf-8")
        print(f"report: {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

# [30DFM-SIG: v1-EBZ15rnyZMe]
