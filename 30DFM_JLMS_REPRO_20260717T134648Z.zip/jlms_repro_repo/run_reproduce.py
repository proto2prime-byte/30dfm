#!/usr/bin/env python3
"""One-command reproducibility entrypoint for the JLMS pack."""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main() -> int:
    ap = argparse.ArgumentParser(description="JLMS reproducibility runner")
    ap.add_argument(
        "--mode",
        choices=("smoke", "quick", "classical"),
        default="smoke",
        help="smoke=<60s; quick=pre-submission battery; classical=strip only",
    )
    args = ap.parse_args()
    py = sys.executable
    if args.mode == "smoke":
        cmd = [py, "scripts/run_jlms_smoke.py"]
    elif args.mode == "classical":
        cmd = [py, "scripts/verify_classical_strip.py"]
    else:
        cmd = [py, "scripts/run_pre_submission_battery.py", "--mode", "quick", "--skip-latex"]
    print("Running:", " ".join(cmd))
    r = subprocess.run(cmd, cwd=str(ROOT))
    return int(r.returncode)


if __name__ == "__main__":
    raise SystemExit(main())
