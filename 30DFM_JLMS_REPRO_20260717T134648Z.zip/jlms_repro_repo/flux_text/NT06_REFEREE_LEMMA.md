# Lemma NT-06 (Referee) — Explicit Huxley → \(\kappa_7\) transfer

**Status:** `REFEREE_READY` · certificate `python scripts/certify_nt06_delta.py`  
**Claim gate:** `clay_rh_claim: false` until peer review accepts the transfer into \(\kappa_7\)  
**Companions:** `HUXLEY_KAPPA7_TRANSFER.md` · Huxley (1972) · Bourgain (2000)

---

## Hypotheses

**Density input (choose one).** Assume a zero-density bound of the form
\[
N(\sigma,T)\ll T^{A(1-\sigma)}(\log T)^{K}
\qquad\bigl(\tfrac12\le\sigma\le 1\bigr)
\]
with explicit \((A,K)\). Standard Huxley (Invent. Math. **15** (1972), Thm 1) gives the classical shape
\[
N(\sigma,T)\ll T^{3(1-\sigma)/(2-\sigma)}(\log T)^{K},
\]
i.e. the effective density exponent
\[
\alpha_H(\sigma)=\frac{3(1-\sigma)}{2-\sigma}
\quad\bigl(\text{equivalent to }A_{\mathrm{Hux}}=\tfrac{3}{2-\sigma}\text{ in }T^{A(1-\sigma)}\bigr).
\]
Bourgain’s density-hypothesis range \(N(\sigma,T)\ll T^{2(1-\sigma)+\varepsilon}\) for \(\sigma\ge 25/32\) may be used as an optional tightening (smaller \(A\)) in that subrange.

**Projection.** Let \(P_{\mathrm{GATE}}\) be the bounded residue/DR projection onto GATE digital roots \(\{2,5,8\}\) on \(\mathbb{Z}/90\mathbb{Z}\) (finite GATE offsets; asymptotic Electric Slide **retracted**). Then \(|P_{\mathrm{GATE}}D|\le|D|\) pointwise and length/smoothness class are not increased.

---

## Lemma NT-06 (explicit \(\delta\))

Write the GapDR energy as \(\mathcal E=\mathcal E_{\mathrm{diag}}+\mathcal E_{\mathrm{cross}}\) with diagonal
\[
\mathcal E_{\mathrm{diag}}\ge c_E\,c_0^2\,X^{2\sigma}
\qquad(c_E=\tfrac12,\ c_0=0.0415).
\]
Under a density bound \(N(\sigma,T)\ll T^{\alpha_H(\sigma)}(\log T)^{K}\) with \(T=X\), Cauchy–Schwarz on the off-diagonal yields
\[
\bigl|\mathcal E_{\mathrm{cross}}\bigr|
\ll
X^{\,\sigma+\alpha_H(\sigma)/2}\,(\log X)^{O(1)}.
\]
Define the **transfer gap**
\[
\boxed{
\delta(\sigma)
:=
2\sigma-\Bigl(\sigma+\tfrac12\alpha_H(\sigma)\Bigr)
=
\sigma-\tfrac12\alpha_H(\sigma).
}
\]
**Conclusion.** Whenever \(\delta(\sigma)>0\),
\[
\mathcal E_{\mathrm{cross}}=O\!\bigl(X^{2\sigma-\delta(\sigma)}(\log X)^{O(1)}\bigr)
=o\!\bigl(X^{2\sigma}\bigr).
\]

### Huxley specialisation

With \(\alpha_H(\sigma)=3(1-\sigma)/(2-\sigma)\),
\[
\delta_{\mathrm{Hux}}(\sigma)
=
\sigma-\frac{3(1-\sigma)}{2(2-\sigma)}.
\]
Elementary algebra: \(\delta_{\mathrm{Hux}}(\sigma)>0\) for all \(\sigma\in(\tfrac12,1]\).

### Density-hypothesis specialisation (optional)

If \(\alpha_H(\sigma)=2(1-\sigma)\) (density hypothesis), then \(\delta_{\mathrm{DH}}(\sigma)=2\sigma-1>0\) for \(\sigma>\tfrac12\).

---

## Worked numeric table

| \(\sigma\) | \(\alpha_H\) (Huxley) | \(\delta_{\mathrm{Hux}}\) | Cross exp \(\sigma+\alpha_H/2\) | Diagonal \(2\sigma\) |
|-----------|------------------------|---------------------------|----------------------------------|----------------------|
| 0.900 | 0.2727 | 0.7636 | 1.0364 | 1.800 |
| 0.776 | 0.5490 | 0.5015 | 1.0505 | 1.552 |
| 0.725 | 0.6471 | 0.4015 | 1.0485 | 1.450 |
| 0.600 | 0.8571 | 0.1714 | 1.0286 | 1.200 |
| 0.550 | 0.9310 | 0.0845 | 1.0155 | 1.100 |
| 0.520 | 0.9730 | 0.0335 | 1.0065 | 1.040 |
| 0.501 | 0.9993 | 0.0013 | 1.0007 | 1.002 |

At \(\sigma=0.725\): required \(\delta>0\) is met with \(\delta_{\mathrm{Hux}}\approx 0.4015\).

Reproduce:
```bash
python scripts/certify_nt06_delta.py
```

---

## Isolation of dependencies

| Slot | Result used | Where a future improvement helps |
|------|-------------|----------------------------------|
| Huxley 1972 | \(\alpha_H=3(1-\sigma)/(2-\sigma)\) | Larger \(\delta\) near \(\sigma=\tfrac12{+}\) |
| Bourgain 2000 | Density hyp. for \(\sigma\ge 25/32\) | Smaller \(A\) in that band → larger \(\delta\) |
| \(P_{\mathrm{GATE}}\) | \(\lvert P D\rvert\le\lvert D\rvert\) | Architecture only; no new density proof |

**Risk mitigation.** Present prize-path as: *conditional on a Huxley-type bound with \(\alpha_H(\sigma)\le 2\sigma-\eta\) for some \(\eta>0\)*. Sensitivity tables show \(\delta(\sigma)\) under Huxley vs density hypothesis.

---

## What this does / does not claim

| Claims | Does not claim |
|--------|----------------|
| Explicit \(\delta(\sigma)\) under cited density | A new zero-density theorem |
| Cross-terms \(o(X^{2\sigma})\) for \(\sigma>1/2\) under Huxley | Unconditional Clay RH |
| Transfer of published \(N(\sigma,T)\) into \(\kappa_7\) bilinear form | Absolute constants in the \(\ll\) of Huxley (logs absorbed in \(o\)) |

---

## Self-contained publish path (PAPER-II)

LaTeX one-pager (compile standalone):

```bash
pdflatex flux_text/papers/nt06_huxley_kappa7_lemma.tex
python scripts/certify_nt06_delta.py
```

**Minimal assumptions for referees:** (H) Huxley 1972 density exponent; (P) bounded GATE projection; diagonal constants \(c_E=1/2\), \(c_0=0.0415\); logs absorbed once \(\delta>0\).

**Public vs personal:** Publish the lemma + machine seal with `clay_rh_claim=false`. Keep any stronger Millennium-facing prose offline until H+P survive peer review.

*verified by vibecheck*
