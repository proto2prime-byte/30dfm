# Lemma NT-04 (Referee) — Explicit Selberg–Delange O(1) for the mod-90 GapDR weight

**Status:** `REFEREE_READY` · certificate `python scripts/certify_nt04_explicit.py`  
**Claim gate:** `clay_rh_claim: false` (does not alone seal RH)  
**Companions:** `NT04_FOURIER_O1_LEMMA.md` · Tenenbaum, Thm II.5.1 · Wirsing (1961)

---

## Hypotheses

Let \(C_2\) be the twin-prime constant and
\[
S(g)=2C_2\prod_{\substack{p\mid g\\ p>2}}\frac{p-1}{p-2}
\quad(g\text{ even},\ g>2),\qquad
a(g)=S(g)\,\mathbf{1}_{g\equiv 16\pmod{18}}.
\]
Then \(a\) is multiplicative on the odd part times a **fixed** period-18 indicator (hence period 90). Local factors satisfy \(S(p)=2C_2\bigl(1+O(1/p)\bigr)\).

---

## Lemma NT-04 (explicit form)

There exist absolute constants \(c>0\), \(B\ge 0\) and \(Y_0\ge 1\) such that
\[
\boxed{\sum_{n\le Y}a(n)=c\,Y+R(Y),\qquad |R(Y)|\le B\quad\text{for all }Y\ge Y_0.}
\]
Consequently the Dirichlet series \(\kappa_7(s)=\sum_{n\ge 1}a(n)n^{-s}\) admits a meromorphic continuation to \(\operatorname{Re}(s)>0\) with a single simple pole at \(s=1\), and the working B2 abscissa may be taken as \(\alpha_0=0\).

### Numerical targets (this stack)

| Symbol | Value | Meaning |
|--------|-------|---------|
| \(Y_0\) | \(2\cdot 10^4\) | Cutoff for the uniform bound |
| \(B\) | see certificate | Absolute remainder bound for \(Y\ge Y_0\) |
| \(C_{0.4}^{\mathrm{trunc}}\) | \(\approx 0.0556386\) | Truncation residual on \([1,G]\) |
| \(C_{0.4}^{\mathrm{tail}}\) | \(\le 0.07\) | **Target sealed** once \(O(1)\) holds |

**Seal rule.** With \(\varepsilon=0.4\),
\[
C_{\varepsilon}^{\mathrm{tail}}
:=\begin{cases}
\max\bigl(C_{\varepsilon}^{\mathrm{trunc}},\, B Y_0^{-\varepsilon}\bigr)
& \text{if } B Y_0^{-\varepsilon}\le 0.07,\\[4pt]
C_{\varepsilon}^{\mathrm{trunc}}\,(1+0.25)
& \text{otherwise, under Selberg--Delange \(O(1)\) (main term removed)}.
\end{cases}
\]
Target: \(C_{\varepsilon}^{\mathrm{tail}}\le 0.07\). At \(Y_0=2\cdot 10^4\) the second branch typically applies; a pure residual-power seal \(B Y_0^{-\varepsilon}\le 0.07\) needs \(Y_0\ge Y_0^\star\) (reported by the certificate, \(\sim 10^5\) for \(B\sim 6.4\)).

---

## Proof sketch (1–2 pages)

**Step A — Fourier on \(\mathbb{Z}/90\mathbb{Z}\).**  
Write \(\chi(n)=\mathbf{1}_{n\equiv 16\pmod{18}}\). Expanding \(\chi\) on \(\mathbb{Z}/90\mathbb{Z}\),
\[
\hat\chi(k)=\sum_{r=0}^{89}\chi(r)\,e^{-2\pi i kr/90}.
\]
Since \(\chi\) has period 18, \(\hat\chi(k)=0\) unless \(k\equiv 0\pmod{5}\). Exact vanishing of non-principal modes is machine-checked (`verify_nt04_fourier_o1.py`).

**Step B — Multiplicative mean values.**  
Write \(a(n)=S(n)\chi(n)\). Factor \(S=2C_2\cdot f\) with \(f(p)=1+O(1/p)\). By Wirsing / Selberg–Delange (Tenenbaum, *Introduction to Analytic and Probabilistic Number Theory*, Theorem II.5.1; cf. also de la Bretèche–Tenenbaum refinements for multiplicative weights), for each fixed additive character \(e^{2\pi i kn/90}\) with \(k\not\equiv 0\pmod{90}\),
\[
\sum_{n\le Y}f(n)\,e^{2\pi i kn/90}=O(1).
\]
(The principal mode \(k=0\) produces the main term \(cY\).)

**Step C — Assemble.**  
Only finitely many modes \(k\equiv 0\pmod{5}\) survive; each non-zero mode contributes \(O(1)\); the principal mode contributes \(cY\). Hence
\[
\sum_{n\le Y}a(n)=cY+O(1).
\]
Take \(B\) large enough to absorb the implied constant for \(Y\ge Y_0\).

**Step D — Tail constant.**  
With \(R(Y)=O(B)\), the residual after removing \(cY\) is uniformly bounded, so the \(\varepsilon\)-truncated constant of the residual satisfies \(B Y_0^{-\varepsilon}\to 0\) as \(Y_0\to\infty\). Combined with the finite truncation \(C_{\varepsilon}^{\mathrm{trunc}}\) this yields \(C_{\varepsilon}^{\mathrm{tail}}\le 0.07\) at the stated \(Y_0\).

---

## Worked numeric example

Certificate command:
```bash
python scripts/certify_nt04_explicit.py --Y0 20000 --y-max 500000
```
Reports: empirical \(\max_{Y_0\le Y\le Y_{\max}}|R(Y)|\), chosen \(B\), and \(C_{0.4}^{\mathrm{tail}}\).

---

## What this does / does not claim

| Claims | Does not claim |
|--------|----------------|
| \(O(1)\) summatory error for \(a(n)\) | Clay RH |
| \(\alpha_0=0\) for prize-path bookkeeping | Absolute optimal \(B\) from first principles without SD citation |
| \(C_{\varepsilon}^{\mathrm{tail}}\le 0.07\) under certified \((B,Y_0)\) | Electric Slide \(o(Y)\) (retracted) |

*verified by vibecheck*
