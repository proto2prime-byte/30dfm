# Appendix — Master inequality with NT-04 + NT-06 (one page)

**Paste target:** PAPER-I or PAPER-II appendix  
**Honesty:** `clay_rh_claim: false` — prize-path under stated hypotheses  
**Reproduce:** `python scripts/reproduce_table.py --X 1e12` · `python scripts/certify_bridge_appendix.py`

---

## Constants table

| Symbol | Value | Role |
|--------|-------|------|
| \(c_E\) | \(1/2\) | Ingham diagonal weight |
| \(c_0\) | \(0.0415\) | GapDR / \(\kappa_7\) normalisation |
| \(C_E\) | \(\le 1\) | Montgomery–Vaughan envelope |
| \(C_{0.4}^{\mathrm{trunc}}\) | \(\approx 0.0556386\) | Truncation residual |
| \(C_{0.4}^{\mathrm{tail}}\) | \(\le 0.07\) | NT-04 seal target |
| \(\alpha_0\) | \(0\) | NT-04 \(O(1)\) ⇒ \(\operatorname{Re}(s)>0\) |
| \(\hat a_{\mathrm{GATE}}(0)\) | \(\approx 6.96097\) | \(P_{\mathrm{GATE}}\) live mode |
| \(\delta_{\mathrm{Hux}}(\sigma)\) | \(\sigma-\frac{3(1-\sigma)}{2(2-\sigma)}\) | NT-06 transfer gap |

---

## Master inequality

Assume Lemma NT-04 (\(O(1)\) summatory ⇒ \(\alpha_0=0\)) and Lemma NT-06 (\(\delta(\sigma)>0\)). For a hypothetical zero with \(\operatorname{Re}\rho=\sigma>\tfrac12\) and large \(X\),
\[
c_E\,c_0^2\,X^{2\sigma}
\le
\mathcal E_{\mathrm{diag}}
\le
\mathcal E
+
\bigl|\mathcal E_{\mathrm{cross}}\bigr|
\le
C_E\,X
+
O\!\bigl(X^{2\sigma-\delta(\sigma)}(\log X)^{O(1)}\bigr).
\]
Divide by \(X\):
\[
\boxed{
R(\sigma,X)
:=
\frac{c_E\,c_0^2}{C_E}\,X^{2\sigma-1}
\le
1
+
O\!\bigl(X^{2\sigma-1-\delta(\sigma)}(\log X)^{O(1)}\bigr).
}
\]
Since \(2\sigma-1>0\) and \(\delta(\sigma)>0\), the right-hand error \(\to 0\) while the left side \(\to\infty\) as \(X\to\infty\). Contradiction.

---

## Insertion map

| Gap | Lemma | Effect on master inequality |
|-----|-------|------------------------------|
| Uniform B2 / finite-\(X\) cliff | NT-04 | \(\alpha_0=0\); abscissa covers every \(\sigma>\tfrac12\) |
| Off-diagonal cancellation | NT-06 | Cross \(o(X^{2\sigma})\); diagonal survives |
| Envelope | MV \(C_E\le 1\) | Upper bound \(O(X)\) |

**Cited mode (PAPER-I):** Ingham cross-terms for \(\sigma>3/4\) only; classical strip \(\sigma_{\mathrm{fix}}\approx 0.776\) independent.  
**Prize-path mode:** NT-04 + NT-06 ⇒ asymptotic obstruction for every \(\sigma>\tfrac12\) under the stated density hypothesis — still **not** a Clay seal until the transfer is accepted.

---

## Numeric check (X = 10¹²)

| \(\sigma\) | \(R(\sigma,X)\) | \(\delta_{\mathrm{Hux}}\) | Abscissa covered (prize_path) |
|-----------|-----------------|---------------------------|-------------------------------|
| 0.900 | \(\sim 3.4\times 10^6\) | 0.76 | Y |
| 0.776 | \(\sim 3.6\times 10^3\) | 0.50 | Y |
| 0.725 | \(\sim 2.2\times 10^2\) | 0.40 | Y |
| 0.501 | \(\sim 9\times 10^{-4}\) at \(X=10^{12}\) | 0.0013 | Y (needs \(X\to\infty\)) |

At \(\sigma=0.501\), finite \(X=10^{12}\) has \(R<1\); the asymptotic \(X\to\infty\) (enabled by \(\alpha_0=0\) and \(\delta>0\)) forces \(R\to\infty\).

*verified by vibecheck*
