# Cover Letter

Journal of the London Mathematical Society

**To the Editors**  
**From:** Gregory Clawson  
**Email:** gp3meo@gmail.com  
**Date:** 17 July 2026  
**Submission system:** EditFlow (PDF only at first submission; matching `.tex` retained)

---

Dear Editors,

Please consider the enclosed manuscript for the *Journal of the London Mathematical Society*.

**Title (working):** A Fixed Zero-Free Strip for zeta(s): Classical Bounds and a Gap–Digital-Root Programme  

**MSC 2020:** 11M26 (primary); 11N05, 11N13, 11A41  

**Context.** We prove a fixed classical zero-free strip Re(s) > sigma_fix ≈ 0.776 as a standard consequence of Trudgian's explicit Vinogradov–Korobov bound (c = 0.0827) and Platt's numerical verification (T0 ≈ 3.06×10^9). A separate GapDR / kappa_7 energy programme is presented as a consistency framework past the Ingham edge sigma = 3/4; it does **not** independently establish the strip. An earlier Electric Slide asymptotic lemma is **retracted** (parity/PNT). Remaining conditional steps towards the critical line (NT-04 Fourier O(1) lemma; NT-06 Huxley→kappa_7 transfer) are listed explicitly with citations. The Riemann Hypothesis is not asserted.

**Reproducibility.** Code, figures, TeX sources, and certificate JSON are deposited in a public GitHub repository (URL to be pasted here after push; see pack `REPO_URL.txt`). Local smoke test: `python run_reproduce.py --mode smoke`. Core check: `python scripts/reproduce_table.py --X 1e12 --mode cited`.

**Accessibility.** Sources follow the joint AMS/EMS/LMS/SIAM *Author Guidelines for Preparing Accessible Mathematics Content* (DOI 10.1137/25M0010799).

**Conflicts of interest.** The author declares no conflicts of interest.

**AI disclosure (LMS Ethical Policy §2.5).** AI tools were used in preparing this work (see Acknowledgements in the PDF and the short declaration below). I retain full responsibility for accuracy and originality. Tools were used primarily in a reviewer capacity, with some coding assistance and suggested refinements; final claims were checked by me.

**Declaration of AI tools**

| Tool | Role |
|------|------|
| DeepSeek | Manuscript/argument review; suggested refinements |
| GitHub Copilot | Coding assistance; suggested refinements |
| Qwen | Manuscript/argument review; suggested refinements |
| Cursor (models: Composer 2.5 and Grok 4.5) | Python coding, TeX/Markdown drafting, verification scripts, figures, packaging; review-style suggestions |
| Vibecheck verification stamp | Project integrity checks on repository artifacts (`*verified by vibecheck*`) |

No AI system is listed as an author. All mathematical claims were reviewed by me before submission.

**Claim honesty.** The manuscript claims a fixed classical strip and machine-checkable certificates. The Riemann Hypothesis is not asserted.

**Suite note (editors only).** Companion drafts PAPER-II–IV form a four-paper foundation suite (overflow / covering / contraction) and are **not** submitted as Millennium solutions; PAPER-II is a conditional extension towards the critical line.

I confirm that the submitted PDF matches a retained `.tex` source, that an abstract is included, and that I am the sole author.

Sincerely,  

Gregory Clawson  
gp3meo@gmail.com  

*verified by vibecheck*
