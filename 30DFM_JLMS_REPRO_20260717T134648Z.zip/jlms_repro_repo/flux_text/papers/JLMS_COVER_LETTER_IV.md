# Cover Letter

Journal of the London Mathematical Society  
PAPER-IV of a four-paper foundation suite (I–IV)

**To the Editors**  
**From:** Gregory Clawson  
**Email:** gp3meo@gmail.com  
**Date:** 17 July 2026  

---

Dear Editors,

Please consider the enclosed manuscript for the *Journal of the London Mathematical Society*.

**Title:** Triadic Energy Contraction for the Collatz Map  

**MSC 2020:** 11B83, 37A45, 11A63  

**Suite.** This is PAPER-IV of a four-paper foundation suite submitted simultaneously (I–IV). It certifies finite Collatz energy contraction for starts \(n\le 10^7\) (mean height increment ≈ −0.166). We do not claim the Collatz conjecture for all \(n\).

**Conflicts of interest.** None declared.

**AI disclosure (LMS Ethical Policy §2.5).** DeepSeek, GitHub Copilot, Qwen, and Cursor (Composer 2.5, Grok 4.5) were used primarily in a reviewer capacity, with coding assistance where noted. Full declaration is in the manuscript Acknowledgements. I retain full responsibility for accuracy and originality.

Sincerely,  
Gregory Clawson  
gp3meo@gmail.com  

*verified by vibecheck*
