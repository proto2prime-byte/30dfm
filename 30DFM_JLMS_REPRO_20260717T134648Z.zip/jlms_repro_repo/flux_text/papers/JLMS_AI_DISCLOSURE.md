# AI Disclosure Statement (LMS Ethical Policy section 2.5)

Include in the **Acknowledgements** of every submitted PDF (and keep identical wording in the matching `.tex`).  
Optional standalone attachment: only if EditFlow requires a separate AI file (otherwise the Acknowledgements section in the manuscript PDF is sufficient).

---

## Acknowledgements (paste into manuscript)

\paragraph{Conflicts of interest.}
The author declares no conflicts of interest.

\paragraph{Declaration of AI tools (LMS Ethical Policy §2.5).}
This work was prepared with assistance from artificial intelligence tools, declared here in accordance with the London Mathematical Society Ethical Policy for Journals (§2.5, Use of Artificial Intelligence). The tools listed below were used primarily in a **reviewer capacity** (cross-checking arguments and suggesting small textual or structural refinements). Where noted, they also assisted with Python coding and manuscript packaging. Suggested refinements were considered by the author; final mathematical claims and wording are the author's.

- **DeepSeek** — manuscript and argument review; suggested refinements.
- **GitHub Copilot** — coding assistance and suggested refinements.
- **Qwen** — manuscript and argument review; suggested refinements.
- **Cursor** (AI coding assistant; models **Composer 2.5** and **Grok 4.5**) — Python coding assistance, drafting LaTeX/Markdown, verification scripts, accessible figures, and submission packaging; also used for review-style suggestions.
- **Vibecheck** — project integrity stamp on repository artifacts (badge: *verified by vibecheck*).

The author checked the accuracy of the manuscript (including all AI-assisted text and computations) before submission and remains fully responsible for all parts of the work, including those involving AI tools. No AI tool is an author of this paper.

*verified by vibecheck*

---

## Notes for EditFlow

- Cover letter field: paste brief context from `JLMS_COVER_LETTER.md` (or attach `JLMS_COVER_LETTER.pdf`).  
- Notes to Editor (editors only): optional note that companion papers II–IV exist as a foundation suite and are **not** claimed as full RH / Goldbach / Collatz proofs.  
- Submit **one PDF** for the article under consideration (recommended first: PAPER-I fixed strip). Keep the matching `.tex`.  
- Foundation suite size: **four** main articles (PAPER-I–IV); PAPER-V is a separate optional complexity note, not part of the I–IV block.
