# Referee Response Template — PAPER-I (JLMS)

**Manuscript:** Fixed zero-free strip for ζ(s); GapDR programme appendix  
**Author:** Gregory Clawson <gp3meo@gmail.com>  
**Honesty gate:** `clay_rh_claim = false`

Use these short rebuttals; point to exact supplement paths.

---

## Objection A — “Selberg–Delange O(1) for this weight is nonstandard.”

**Response.**  
We provide a self-contained lemma (NT-04) with explicit constants, a proof sketch referencing Tenenbaum (Thm II.5.1) and the mod-90 Fourier reduction, and reproducible code that certifies the tail constant \(C_{0.4}^{\mathrm{tail}}\le 0.069548\).

**Pointers.**  
- `flux_text/NT04_REFEREE_LEMMA.md`  
- `scripts/certify_nt04_explicit.py` → `benchmark_outputs/rh_continuation/nt04_explicit_last.json`  
- PAPER-I Appendix A (Lemma NT-04)  
- PDF: `NT04_NT06_REFEREE_LEMMAS.pdf`

---

## Objection B — “Huxley transfer to κ₇ needs more bookkeeping.”

**Response.**  
NT-06 is an explicit transfer lemma with full exponent algebra and a worked numeric example (σ=0.725 ⇒ δ≈0.4015). We isolate the exact density hypothesis used (Huxley 1972) so the claim is transparent and verifiable; we do not claim a new zero-density theorem.

**Pointers.**  
- `flux_text/NT06_REFEREE_LEMMA.md`  
- `scripts/certify_nt06_delta.py` → `nt06_delta_last.json`  
- PAPER-I Appendix A (Lemma NT-06)  
- Optional tightening citation: Bourgain IMRN 2000 (density hyp. for σ≥25/32)

---

## Objection C — “Numerics are exploratory.”

**Response.**  
All numerics are reproducible via the supplied scripts; we include CI smoke tests and SHA256 checksums for the main JSON outputs.

**Pointers.**  
- `python scripts/reproduce_table.py --X 1e12 --mode cited`  
- `python scripts/certify_bridge_appendix.py`  
- `python scripts/sensitivity_table.py --X 1e12`  
- `benchmark_outputs/jlms_submission/SUBMISSION_CHECKSUMS.txt`  
- `.github/workflows/jlms-smoke.yml`

---

## Objection D — “Is this a Clay RH claim?”

**Response.**  
No. Theorem 1 (fixed strip σ_fix≈0.776) is classical-computational (Trudgian VK + Platt T₀). The prize-path obstruction for every σ>1/2 is **conditional** on NT-04 and NT-06. The flag `clay_rh_claim` remains false throughout the repository.

---

## Objection E — “Adjust C_E / Y₀?”

**Response.**  
The sensitivity table (`sensitivity_table_last.json`) shows R(σ,X) under ±5% on c₀ and alternate c_E, C_E. For NT-04: at Y₀=2×10⁴ the seal uses trunc-safety under Selberg–Delange O(1); a pure residual-power seal B Y₀^{-ε}≤0.07 requires Y₀⋆∼10⁵ (reported in the certificate). Changing C_E scales R linearly; δ_Hux(σ) is independent of (c_E,c₀,C_E).

*verified by vibecheck*
