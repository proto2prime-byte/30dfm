# NT-04 — Fourier O(1) Lemma (Selberg–Delange bypass)

**Status:** `PROVEN_LEMMA` (fixed modulus 90; citation + discrete Fourier proof)  
**Bypasses:** finite-\(X\) energy cliff near \(\sigma=1/2+\varepsilon\) — enables \(\alpha_0=0\) without Electric Slide  
**Claim gate:** `clay_rh_claim: false` — Huxley→\(\kappa_7\) translation still peer review  
**Certificate:** `python scripts/verify_nt04_fourier_o1.py` → `nt04_fourier_o1_last.json`

---

## 1. Weight

\[
a(g) = S(g)\,\mathbf{1}_{g\equiv 16\pmod{18}},
\qquad
S(g)=2C_2\prod_{\substack{p\mid g\\ p>2}}\frac{p-1}{p-2},
\]
with \(C_2\) the twin-prime constant. Then \(S(p)=2C_2(1+O(1/p))\) and \(a\) is multiplicative on the odd part times a **fixed** periodic indicator (period 18, hence 90).

---

## 2. Discrete Fourier reduction (one page)

Fix \(q=90\). Write \(\chi(g)=\mathbf{1}_{g\equiv 16\pmod{18}}\) viewed on \(\mathbb{Z}/90\mathbb{Z}\) (five supported residues per period).

**Step A — Character expansion.** For each \(k\bmod 90\),
\[
\hat\chi(k)=\sum_{r=0}^{89}\chi(r)\,e^{-2\pi i kr/90}.
\]
Since \(\chi\) has period \(18\) on \(\mathbb{Z}\), only modes with \(k\equiv 0\pmod{5}\) (i.e. \(90/18=5\)) can be nonzero. All other modes vanish **exactly** by discrete orthogonality.

**Step B — Non-principal twisted sums.** For \(k\not\equiv 0\pmod{5}\) (equivalently non-constant characters on the 18-period sublattice), twisted sums are \(O(1)\) by Selberg–Delange. For the finitely many remaining non-zero modes (\(k=5,10,\ldots\)), the same bound applies mode-by-mode.

**Step C — Principal mode.** The \(k=0\) mode yields
\[
\sum_{g\le Y} a(g) = c\,Y + O(1),
\qquad
c=\frac{1}{90}\sum_{r=0}^{89} S(r)\chi(r) + \text{lower-order}.
\]

**Conclusion (Lemma NT-04).**  
\[
\sum_{g\le Y} a(g) = c\,Y + O(1).
\]
Hence the Dirichlet series \(\sum a(g) g^{-s}\) converges for \(\Re(s)>0\) and the working B2 abscissa is \(\alpha_0=0\).

---

## 3. Consequence for the energy bridge

Demanded abscissa \(\alpha=2(\sigma-\tfrac12)\). For any \(\sigma>\tfrac12\), \(\alpha>0\), so abscissa coverage holds **without** astronomical \(X\). Combined with `--constants prize_path --asymptotic` and NT-06 (Huxley programme), the Anti-Solver obstruction at \(\sigma>1/2\) is an **asymptotic** energy argument, not a finite-\(X=10^{153}\) extrapolation.

---

## 4. What this does / does not claim

| Claims | Does not claim |
|--------|----------------|
| \(O(1)\) summatory error for HL×mod-18 weight | Electric Slide \(o(Y)\) (retracted) |
| \(\alpha_0=0\) for B2 bookkeeping | Clay Millennium RH seal |
| Removes finite-\(X\) cliff for prize-path **programme** | Unconditional classical ζ translation without Huxley peer review |

---

## 5. References

- G. Tenenbaum, *Introduction to Analytic and Probabilistic Number Theory*, Theorem II.5.1 (Selberg–Delange).  
- E. Wirsing (1961), multiplicative functions mean values.  
- Companion: `LEMMA_B1_PRIME.md` §4bis, `paper_ii_rh_prize_path.md` §2.

*verified by vibecheck*
