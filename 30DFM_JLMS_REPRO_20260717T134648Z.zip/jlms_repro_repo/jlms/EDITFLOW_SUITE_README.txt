JLMS EditFlow — Foundation Suite (PAPER-I–IV)
=============================================
Built UTC: 20260717T125937Z

JLMS accepts PDF only. Upload FOUR separate EditFlow submissions.
Put zips on GitHub (not EditFlow).

Submission 1 — PAPER-I
  Manuscript: paper_i_fixed_strip_0776.pdf
  Cover:      JLMS_COVER_LETTER.pdf
  TeX keep:  flux_text/papers/paper_i_fixed_strip_0776.tex

Submission 2 — PAPER-II
  Manuscript: paper_ii_rh_prize_path.pdf
  Cover:      JLMS_COVER_LETTER_II.pdf
  TeX keep:  flux_text/papers/paper_ii_rh_prize_path.tex

Submission 3 — PAPER-III
  Manuscript: paper_iii_gate_sieve_goldbach_twin.pdf
  Cover:      JLMS_COVER_LETTER_III.pdf
  TeX keep:  flux_text/papers/paper_iii_gate_sieve_goldbach_twin.tex

Submission 4 — PAPER-IV
  Manuscript: paper_iv_collatz_energy.pdf
  Cover:      JLMS_COVER_LETTER_IV.pdf
  TeX keep:  flux_text/papers/paper_iv_collatz_energy.tex

Optional on every submission:
  JLMS_AI_DISCLOSURE.pdf

GitHub (same day — do NOT wait for acceptance):
  benchmark_outputs/github_release/30DFM_GITHUB_SUITE_20260717T125937Z.zip
  Also: 30DFM_JLMS_SUPPLEMENTARY_v1_*.zip (scripts + JSON certs)

In each EditFlow cover / notes field, mention:
  Companion papers I–IV submitted simultaneously as a foundation suite.
  The Riemann Hypothesis and Collatz conjecture are not asserted.

Submit: https://www.lms.ac.uk/publications/jlms/submission
AI policy: https://www.lms.ac.uk/publications/policies/AI

*verified by vibecheck*
