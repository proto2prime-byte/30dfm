# 30DFM / GapDR — JLMS Reproducibility Package

**Author:** Gregory Clawson (`gp3meo@gmail.com`)  
**Stamp:** `20260717T134620Z`  
**Honesty:** The Riemann Hypothesis is not asserted. The Collatz conjecture is not asserted.  
An earlier Electric Slide *asymptotic* lemma is **retracted** (parity / PNT).

This repository accompanies four manuscripts submitted to the
*Journal of the London Mathematical Society* (EditFlow, PDF only).
It contains the Python code, figures, TeX sources, and certificate JSON
needed to reproduce the numerical claims.

---

## Quick start (referee smoke, ~1 minute)

```bash
python -m pip install -r requirements.txt
python run_reproduce.py --mode smoke
```

Expected: `all_ok: true` (or exit code 0).

### Full battery (recommended before citing)

```bash
python run_reproduce.py --mode quick
```

### Core PAPER-I commands

```bash
python scripts/verify_classical_strip.py
python scripts/reproduce_table.py --X 1e12 --mode cited
python scripts/certify_nt04_explicit.py
python scripts/certify_nt06_delta.py
python scripts/certify_bridge_appendix.py
python scripts/verify_gate_projection.py
```

### Papers III–IV certificates

```bash
python scripts/goldbach_slide.py --limit 10000000
python scripts/twin_slide.py --limit 100000
python scripts/collatz_energy_bridge.py --limit 10000000
```

### Regenerate figures

```bash
python scripts/generate_foundation_suite_figures.py
```

Outputs land in `benchmark_outputs/rh_continuation/` and `flux_text/papers/figures/`.

---

## Layout

| Path | Contents |
|------|----------|
| `manuscripts/` | PDF manuscripts (papers I–IV) |
| `flux_text/papers/` | TeX sources + figures |
| `flux_text/*.md` | Referee lemmas (NT-04 / NT-06) |
| `scripts/` | Verification and certificate runners |
| `benchmark_outputs/rh_continuation/` | Precomputed certificate JSON |
| `jlms/` | Cover letters, AI disclosure, checksums |
| `run_reproduce.py` | One-command smoke / quick battery |

---

## Link this repo from JLMS

1. Create a **public** GitHub repository.
2. Upload / push the contents of this folder as the repo root
   (or unzip `30DFM_JLMS_REPRO_*.zip` and push).
3. Copy the public URL into:
   - EditFlow “Notes to editor” / cover letter field
   - Optional: a footnote or Acknowledgements line in the PDF on revision
4. Paste the same URL into `REPO_URL.txt` in this folder for your records.

Example cover-letter sentence:

> Code and certificates reproducing the numerical claims are publicly available at  
> `https://github.com/<you>/<repo>` (tag / commit SHA: `<fill after push>`).

LMS Data Access Policy: deposit code/data in a repository **prior to** or **with** submission.

---

## Requirements

- Python 3.10+
- `matplotlib` (figures only)
- Standard library for all certificate scripts

See `requirements.txt`.

---

## AI tools

Declared in manuscript Acknowledgements and `jlms/JLMS_AI_DISCLOSURE.pdf`
(LMS Ethical Policy section 2.5): DeepSeek, GitHub Copilot, Qwen, Cursor
(Composer 2.5 / Grok 4.5), Vibecheck. No AI tool is an author.

---

## Contact

Gregory Clawson — gp3meo@gmail.com

*verified by vibecheck*
